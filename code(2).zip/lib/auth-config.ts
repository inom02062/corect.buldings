// Authentication configuration
export interface AuthCredentials {
  username: string
  password: string
}

export type UserRole = "admin" | "manager" | "accountant" | "viewer"

export interface User {
  id: string
  username: string
  role: UserRole
}

// EDIT HERE: Change username and password
const VALID_CREDENTIALS: Record<string, { password: string; role: UserRole }> = {
  gtk: { password: "12345", role: "admin" },
  manager: { password: "manager123", role: "manager" },
  accountant: { password: "accountant123", role: "accountant" },
  viewer: { password: "viewer123", role: "viewer" },
}

export function validateCredentials(username: string, password: string): User | null {
  const cred = VALID_CREDENTIALS[username]
  if (cred && cred.password === password) {
    return {
      id: username,
      username: username,
      role: cred.role,
    }
  }
  return null
}

export const ROLE_PERMISSIONS = {
  admin: ["view_all", "edit_all", "delete_all", "manage_users"],
  manager: ["view_all", "edit_apartments", "manage_payments"],
  accountant: ["view_all", "view_payments", "export_reports"],
  viewer: ["view_all"],
}
