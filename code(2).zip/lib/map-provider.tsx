"use client"

import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react"
import type { BlockMap, BlockPosition } from "./types"

interface MapContextType {
  maps: BlockMap[]
  currentMapId: string | null
  createMap: (name: string) => void
  deleteMap: (mapId: string) => void
  setCurrentMap: (mapId: string) => void
  addBlockToMap: (mapId: string, blockPosition: BlockPosition) => void
  removeBlockFromMap: (mapId: string, blockId: string) => void
  updateBlockPosition: (mapId: string, blockId: string, x: number, y: number, width: number, height: number) => void
  getCurrentMap: () => BlockMap | null
  loading: boolean
  error: string | null
}

const MapContext = createContext<MapContextType | undefined>(undefined)

const MAP_STORAGE_KEY = "building-maps-data"
const USE_DATABASE = false // Set to true when Supabase is connected

export function MapProvider({ children }: { children: ReactNode }) {
  const [maps, setMaps] = useState<BlockMap[]>([])
  const [currentMapId, setCurrentMapId] = useState<string | null>(null)
  const [mounted, setMounted] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    setMounted(true)
    initializeMaps()
  }, [])

  useEffect(() => {
    if (!mounted) return

    if (typeof window !== "undefined" && !USE_DATABASE) {
      try {
        localStorage.setItem(MAP_STORAGE_KEY, JSON.stringify(maps))
      } catch (err) {
        console.error("Failed to save maps to localStorage:", err)
        setError("Failed to save maps")
      }
    }
  }, [maps, mounted])

  const initializeMaps = async () => {
    try {
      setLoading(true)

      if (USE_DATABASE) {
        const response = await fetch("/api/maps")
        if (!response.ok) throw new Error("Failed to fetch maps")
        const dbMaps = await response.json()
        setMaps(dbMaps)
        if (dbMaps.length > 0) {
          setCurrentMapId(dbMaps[0].id)
        }
      } else {
        // Fallback to localStorage
        if (typeof window !== "undefined") {
          const stored = localStorage.getItem(MAP_STORAGE_KEY)
          if (stored) {
            const parsedMaps = JSON.parse(stored)
            setMaps(parsedMaps)
            if (parsedMaps.length > 0) {
              setCurrentMapId(parsedMaps[0].id)
            }
          } else {
            // Create default map
            const defaultMap: BlockMap = {
              id: "default-map",
              name: "Asosiy Xarita",
              blocks: [],
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
            }
            setMaps([defaultMap])
            setCurrentMapId(defaultMap.id)
          }
        }
      }
    } catch (err) {
      console.error("Failed to initialize maps:", err)
      setError("Failed to load maps. Using local storage.")
    } finally {
      setLoading(false)
    }
  }

  const createMap = useCallback((name: string) => {
    const newMap: BlockMap = {
      id: `map-${Date.now()}`,
      name,
      blocks: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    setMaps((prev) => [...prev, newMap])
    setCurrentMapId(newMap.id)

    if (USE_DATABASE) {
      fetch("/api/maps", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newMap),
      }).catch((err) => console.error("Failed to create map in database:", err))
    }
  }, [])

  const deleteMap = useCallback(
    (mapId: string) => {
      setMaps((prev) => prev.filter((m) => m.id !== mapId))
      if (currentMapId === mapId) {
        setCurrentMapId(null)
      }

      if (USE_DATABASE) {
        fetch(`/api/maps/${mapId}`, {
          method: "DELETE",
        }).catch((err) => console.error("Failed to delete map from database:", err))
      }
    },
    [currentMapId],
  )

  const addBlockToMap = useCallback((mapId: string, blockPosition: BlockPosition) => {
    setMaps((prev) =>
      prev.map((map) => {
        if (map.id !== mapId) return map
        return {
          ...map,
          blocks: [...map.blocks, blockPosition],
          updatedAt: new Date().toISOString(),
        }
      }),
    )
  }, [])

  const removeBlockFromMap = useCallback((mapId: string, blockId: string) => {
    setMaps((prev) =>
      prev.map((map) => {
        if (map.id !== mapId) return map
        return {
          ...map,
          blocks: map.blocks.filter((b) => b.blockId !== blockId),
          updatedAt: new Date().toISOString(),
        }
      }),
    )
  }, [])

  const updateBlockPosition = useCallback(
    (mapId: string, blockId: string, x: number, y: number, width: number, height: number) => {
      setMaps((prev) =>
        prev.map((map) => {
          if (map.id !== mapId) return map
          return {
            ...map,
            blocks: map.blocks.map((b) => (b.blockId === blockId ? { ...b, x, y, width, height } : b)),
            updatedAt: new Date().toISOString(),
          }
        }),
      )
    },
    [],
  )

  const getCurrentMap = useCallback(() => {
    return maps.find((m) => m.id === currentMapId) || null
  }, [maps, currentMapId])

  return (
    <MapContext.Provider
      value={{
        maps,
        currentMapId,
        createMap,
        deleteMap,
        setCurrentMap: setCurrentMapId,
        addBlockToMap,
        removeBlockFromMap,
        updateBlockPosition,
        getCurrentMap,
        loading,
        error,
      }}
    >
      {children}
    </MapContext.Provider>
  )
}

export function useMap() {
  const context = useContext(MapContext)
  if (context === undefined) {
    throw new Error("useMap must be used within a MapProvider")
  }
  return context
}
