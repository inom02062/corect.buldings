"use client"

import type { ExportData } from "./export-utils"

export async function downloadPDF(data: ExportData): Promise<void> {
  try {
    const printWindow = window.open("", "", "width=800,height=600")
    if (!printWindow) throw new Error("Print window ochilmadi")

    const htmlContent = generatePDFHTML(data)
    printWindow.document.write(htmlContent)
    printWindow.document.close()

    // Wait for content to load before printing
    printWindow.onload = () => {
      printWindow.print()
      // Close after print dialog opens
      setTimeout(() => printWindow.close(), 500)
    }

    // Fallback if onload doesn't fire
    setTimeout(() => {
      if (printWindow && !printWindow.closed) {
        printWindow.print()
        setTimeout(() => printWindow.close(), 500)
      }
    }, 1000)
  } catch (error) {
    console.error("[v0] PDF download error:", error)
    throw new Error("PDF yuklab olib bo'lmadi")
  }
}

function generatePDFHTML(data: ExportData): string {
  const rows = data.apartments
    .map(
      (apt) => `
      <tr>
        <td style="padding: 8px; border: 1px solid #ddd;">${apt.blockName}</td>
        <td style="padding: 8px; border: 1px solid #ddd;">${apt.apartmentNumber}</td>
        <td style="padding: 8px; border: 1px solid #ddd;">${apt.floor}</td>
        <td style="padding: 8px; border: 1px solid #ddd;">${getStatusDisplay(apt.status)}</td>
        <td style="padding: 8px; border: 1px solid #ddd;">${apt.customerName || "-"}</td>
        <td style="padding: 8px; border: 1px solid #ddd;">${apt.phone || "-"}</td>
        <td style="padding: 8px; border: 1px solid #ddd;">${apt.monthlyPayment || "-"}</td>
      </tr>
    `,
    )
    .join("")

  return `
    <!DOCTYPE html>
    <html lang="uz">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Bino Boshqaruvi Hisoboti</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Arial', sans-serif; padding: 20px; background: white; }
        .container { max-width: 1200px; margin: 0 auto; }
        .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 15px; }
        .header h1 { font-size: 24px; color: #333; margin-bottom: 5px; }
        .header p { color: #666; font-size: 14px; }
        .stats { display: grid; grid-template-columns: repeat(5, 1fr); gap: 15px; margin-bottom: 30px; }
        .stat-box { 
          background: #f5f5f5; 
          padding: 15px; 
          border-radius: 8px; 
          text-align: center; 
          border-left: 4px solid #2563eb;
        }
        .stat-box h3 { font-size: 24px; font-weight: bold; color: #2563eb; }
        .stat-box p { font-size: 12px; color: #666; margin-top: 5px; }
        .section { margin-bottom: 30px; }
        .section h2 { font-size: 18px; color: #333; margin-bottom: 15px; border-bottom: 2px solid #e5e7eb; padding-bottom: 8px; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #2563eb; color: white; padding: 12px; text-align: left; font-size: 13px; font-weight: bold; }
        td { padding: 10px; border: 1px solid #ddd; font-size: 12px; }
        tr:nth-child(even) { background: #f9fafb; }
        .footer { margin-top: 40px; text-align: center; color: #999; font-size: 11px; border-top: 1px solid #e5e7eb; padding-top: 15px; }
        @media print { body { margin: 0; padding: 0; } .no-print { display: none; } }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Bino Boshqaruvi Hisoboti</h1>
          <p>Tayyorlangan: ${data.exportDate}</p>
        </div>

        <div class="stats">
          <div class="stat-box">
            <h3>${data.stats.totalApartments}</h3>
            <p>Jami kvartiralar</p>
          </div>
          <div class="stat-box">
            <h3>${data.stats.occupied}</h3>
            <p>Obunachilar</p>
          </div>
          <div class="stat-box">
            <h3>${data.stats.paid}</h3>
            <p>To'langanlari</p>
          </div>
          <div class="stat-box">
            <h3>${data.stats.available}</h3>
            <p>Bo'sh</p>
          </div>
          <div class="stat-box">
            <h3>${data.stats.late}</h3>
            <p>Kechikayotgan</p>
          </div>
        </div>

        <div class="section">
          <h2>Bloklar Bo'yicha Tahlil</h2>
          <table>
            <thead>
              <tr>
                <th>Blok nomi</th>
                <th>Jami</th>
                <th>Obunachilar</th>
                <th>To'langanlari</th>
                <th>Bo'sh</th>
                <th>Kechikayotgan</th>
              </tr>
            </thead>
            <tbody>
              ${data.blocks
                .map(
                  (block) => `
                <tr>
                  <td><strong>${block.name}</strong></td>
                  <td>${block.totalApartments}</td>
                  <td>${block.occupied}</td>
                  <td>${block.paid}</td>
                  <td>${block.available}</td>
                  <td>${block.late}</td>
                </tr>
              `,
                )
                .join("")}
            </tbody>
          </table>
        </div>

        <div class="section">
          <h2>Kvartiralar Ro'yxati</h2>
          <table>
            <thead>
              <tr>
                <th>Blok</th>
                <th>Kvartira #</th>
                <th>Qavat</th>
                <th>Status</th>
                <th>Mijozning ismi</th>
                <th>Telefon</th>
                <th>Oylik to'lov</th>
              </tr>
            </thead>
            <tbody>
              ${rows}
            </tbody>
          </table>
        </div>

        <div class="footer">
          <p>Bu hisobot avtomatik tizim tomonidan tayyorlandi.</p>
        </div>
      </div>
    </body>
    </html>
  `
}

function getStatusDisplay(status: string): string {
  const statusMap: Record<string, string> = {
    bosh: "Bo'sh",
    tolayotganlar: "To'layotgan",
    tolangan: "To'langan",
    tolanmagan: "To'lanmagan",
    kechikayotgan: "Kechikayotgan",
  }
  return statusMap[status] || status
}
