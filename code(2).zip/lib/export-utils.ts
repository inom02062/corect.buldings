import type { Block, BuildingStats } from "@/lib/types"

export interface ExportData {
  title: string
  exportDate: string
  stats: BuildingStats
  blocks: Array<{
    name: string
    totalApartments: number
    occupied: number
    available: number
    paid: number
    late: number
  }>
  apartments: Array<{
    blockName: string
    apartmentNumber: string
    floor: number
    status: string
    customerName?: string
    phone?: string
    monthlyPayment?: number
  }>
}

export function prepareExportData(blocks: Block[], stats: BuildingStats): ExportData {
  const apartments: ExportData["apartments"] = []

  blocks.forEach((block) => {
    block.floors.forEach((floor) => {
      floor.apartments.forEach((apt) => {
        apartments.push({
          blockName: block.name,
          apartmentNumber: apt.number,
          floor: floor.number,
          status: apt.status,
          customerName: apt.customerInfo?.name,
          phone: apt.customerInfo?.phone,
          monthlyPayment: apt.customerInfo?.monthlyPayment,
        })
      })
    })
  })

  const blocksSummary = blocks.map((block) => {
    let occupied = 0,
      available = 0,
      paid = 0,
      late = 0

    block.floors.forEach((floor) => {
      floor.apartments.forEach((apt) => {
        if (apt.status === "bosh") available++
        else if (apt.status === "tolayotganlar") occupied++
        else if (apt.status === "tolangan") paid++
        else if (apt.status === "kechikayotgan") late++
      })
    })

    return {
      name: block.name,
      totalApartments: block.totalApartments,
      occupied,
      available,
      paid,
      late,
    }
  })

  return {
    title: "Bino Boshqaruvi Hisoboti",
    exportDate: new Date().toLocaleDateString("uz-UZ"),
    stats,
    blocks: blocksSummary,
    apartments,
  }
}

export function exportToCSV(data: ExportData): string {
  let csv = "Bino Boshqaruvi Hisoboti\n"
  csv += `Tayyorlangan: ${data.exportDate}\n\n`

  csv += "UMUMIY STATISTIKA\n"
  csv += `Jami kvartiralar,${data.stats.totalApartments}\n`
  csv += `Obunachilari,${data.stats.occupied}\n`
  csv += `To'langanlari,${data.stats.paid}\n`
  csv += `Bo'sh,${data.stats.available}\n`
  csv += `Kechikayotganlari,${data.stats.late}\n\n`

  csv += "BLOKLAR BO'YICHA\n"
  csv += "Blok nomi,Jami,Obunachilar,To'langanlari,Bo'sh,Kechikayotgan\n"
  data.blocks.forEach((block) => {
    csv += `"${block.name}",${block.totalApartments},${block.occupied},${block.paid},${block.available},${block.late}\n`
  })

  csv += "\nKVARTIRALAR RO'YXATI\n"
  csv += "Blok,Kvartira #,Qavat,Status,Mijozning ismi,Telefon,Oylik to'lov\n"
  data.apartments.forEach((apt) => {
    const status = getStatusName(apt.status)
    csv += `"${apt.blockName}",${apt.apartmentNumber},${apt.floor},"${status}","${apt.customerName || ""}","${apt.phone || ""}",${apt.monthlyPayment || ""}\n`
  })

  return csv
}

export function downloadCSV(data: ExportData): void {
  try {
    const csv = exportToCSV(data)
    const element = document.createElement("a")
    const file = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" })

    element.href = URL.createObjectURL(file)
    element.download = `Hisobot-${data.exportDate.replace(/\./g, "-")}.csv`

    document.body.appendChild(element)
    element.click()

    document.body.removeChild(element)

    setTimeout(() => {
      URL.revokeObjectURL(element.href)
    }, 100)
  } catch (error) {
    console.error("[v0] CSV export error:", error)
    throw new Error("CSV yuklab olib bo'lmadi")
  }
}

function getStatusName(status: string): string {
  const statusMap: Record<string, string> = {
    bosh: "Bo'sh",
    tolayotganlar: "To'layotgan",
    tolangan: "To'langan",
    tolanmagan: "To'lanmagan",
    kechikayotgan: "Kechikayotgan",
  }
  return statusMap[status] || status
}
