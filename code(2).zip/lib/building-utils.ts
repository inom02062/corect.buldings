import type { Block, BuildingStats, ApartmentStatus } from "./types"

export function calculateBuildingStats(blocks: Block[]): BuildingStats {
  let totalApartments = 0
  let occupied = 0
  let paid = 0
  let available = 0
  let late = 0

  blocks.forEach((block) => {
    block.floors.forEach((floor) => {
      floor.apartments.forEach((apartment) => {
        totalApartments++
        if (apartment.status === "tolayotganlar") occupied++
        else if (apartment.status === "tolangan") paid++
        else if (apartment.status === "bosh") available++
        else if (apartment.status === "kechikayotgan") late++
      })
    })
  })

  return {
    totalApartments,
    occupied,
    paid,
    available,
    late,
  }
}

export function calculateBlockStats(block: Block) {
  let bosh = 0
  let band = 0
  let tolangan = 0
  let kechikayotgan = 0

  block.floors.forEach((floor) => {
    floor.apartments.forEach((apartment) => {
      if (apartment.status === "bosh") bosh++
      else if (apartment.status === "tolayotganlar" || apartment.status === "tolanmagan") band++
      else if (apartment.status === "tolangan") tolangan++
      else if (apartment.status === "kechikayotgan") kechikayotgan++
    })
  })

  return { bosh, band, tolangan, kechikayotgan }
}

export function getStatusColor(status: ApartmentStatus): string {
  switch (status) {
    case "bosh":
      return "bg-gray-600"
    case "tolayotganlar":
      return "bg-red-600"
    case "tolangan":
      return "bg-green-600"
    case "tolanmagan":
      return "bg-orange-600"
    case "kechikayotgan":
      return "bg-yellow-600"
    default:
      return "bg-gray-600"
  }
}

export function getStatusLabel(status: ApartmentStatus): string {
  switch (status) {
    case "bosh":
      return "Bo'sh"
    case "tolayotganlar":
      return "To'layotganlar"
    case "tolangan":
      return "To'langan"
    case "tolanmagan":
      return "To'lanmagan"
    case "kechikayotgan":
      return "Kechikayotgan"
    default:
      return "Bo'sh"
  }
}
