/**
 * Real-time data synchronization utilities
 * Works with Supabase real-time subscriptions when database is enabled
 */

type SyncCallback<T> = (data: T) => void

interface RealtimeSyncSubscription {
  unsubscribe: () => void
}

export class RealtimeSync {
  private subscribers: Map<string, Set<SyncCallback<any>>> = new Map()
  private pollIntervals: Map<string, NodeJS.Timeout> = new Map()

  /**
   * Subscribe to changes for a specific resource
   */
  subscribe<T>(resourceKey: string, callback: SyncCallback<T>): RealtimeSyncSubscription {
    if (!this.subscribers.has(resourceKey)) {
      this.subscribers.set(resourceKey, new Set())
    }

    const callbacks = this.subscribers.get(resourceKey)!
    callbacks.add(callback)

    // Start polling if not already active
    if (!this.pollIntervals.has(resourceKey)) {
      this.startPolling(resourceKey)
    }

    return {
      unsubscribe: () => {
        callbacks.delete(callback)
        if (callbacks.size === 0) {
          this.stopPolling(resourceKey)
        }
      },
    }
  }

  /**
   * Broadcast changes to all subscribers
   */
  broadcast<T>(resourceKey: string, data: T): void {
    const callbacks = this.subscribers.get(resourceKey)
    if (callbacks) {
      callbacks.forEach((callback) => {
        try {
          callback(data)
        } catch (error) {
          console.error(`Error in sync callback for ${resourceKey}:`, error)
        }
      })
    }
  }

  /**
   * Start polling for changes (used when real-time subscriptions aren't available)
   */
  private startPolling(resourceKey: string): void {
    const interval = setInterval(() => {
      // Polling logic will be implemented per resource
      // This is a placeholder for the polling mechanism
    }, 5000) // Poll every 5 seconds

    this.pollIntervals.set(resourceKey, interval)
  }

  /**
   * Stop polling for a resource
   */
  private stopPolling(resourceKey: string): void {
    const interval = this.pollIntervals.get(resourceKey)
    if (interval) {
      clearInterval(interval)
      this.pollIntervals.delete(resourceKey)
    }
  }

  /**
   * Clear all subscriptions
   */
  clear(): void {
    this.pollIntervals.forEach((interval) => clearInterval(interval))
    this.pollIntervals.clear()
    this.subscribers.clear()
  }
}

export const realtimeSync = new RealtimeSync()
