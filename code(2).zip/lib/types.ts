export type ApartmentStatus = "bosh" | "tolayotganlar" | "tolangan" | "tolanmagan" | "kechikayotgan"

export interface PaymentRecord {
  month: string // Format: "2024-01"
  amount: number
  date: string // Payment date
}

export interface CustomerInfo {
  name: string
  phone: string
  entryDate: string
  monthlyPayment: number
  lastPaymentDate?: string
  paymentHistory?: PaymentRecord[]
}

export interface Apartment {
  id: number
  number: string
  status: ApartmentStatus
  owner?: string
  customerInfo?: CustomerInfo
  floor: number
  block: string
}

export interface Floor {
  number: number
  apartments: Apartment[]
}

export interface Block {
  id: string
  name: string
  totalFloors: number
  totalApartments: number
  floors: Floor[]
}

export interface BuildingStats {
  totalApartments: number
  occupied: number
  paid: number
  available: number
  late: number
}

export interface BlockPosition {
  blockId: string
  x: number
  y: number
  width: number
  height: number
}

export interface BlockMap {
  id: string
  name: string
  blocks: BlockPosition[]
  createdAt: string
  updatedAt: string
}
