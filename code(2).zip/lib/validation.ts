/**
 * Data validation utilities
 */

export interface ValidationError {
  field: string
  message: string
}

export interface ValidationResult {
  valid: boolean
  errors: ValidationError[]
}

// Apartment validation
export function validateApartment(apartment: any): ValidationResult {
  const errors: ValidationError[] = []

  if (!apartment.id) {
    errors.push({ field: "id", message: "Apartment ID is required" })
  }

  if (!apartment.number || typeof apartment.number !== "string") {
    errors.push({ field: "number", message: "Apartment number must be a valid string" })
  }

  if (
    !apartment.status ||
    !["bosh", "tolayotganlar", "tolangan", "tolanmagan", "kechikayotgan"].includes(apartment.status)
  ) {
    errors.push({ field: "status", message: "Invalid apartment status" })
  }

  if (apartment.floor && !Number.isInteger(apartment.floor)) {
    errors.push({ field: "floor", message: "Floor must be an integer" })
  }

  if (apartment.block && typeof apartment.block !== "string") {
    errors.push({ field: "block", message: "Block must be a valid string" })
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}

// Block validation
export function validateBlock(block: any): ValidationResult {
  const errors: ValidationError[] = []

  if (!block.name || typeof block.name !== "string") {
    errors.push({ field: "name", message: "Block name is required and must be a string" })
  }

  if (!Number.isInteger(block.totalFloors) || block.totalFloors <= 0) {
    errors.push({ field: "totalFloors", message: "Total floors must be a positive integer" })
  }

  if (!Number.isInteger(block.totalApartments) || block.totalApartments <= 0) {
    errors.push({ field: "totalApartments", message: "Total apartments must be a positive integer" })
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}

// Block position validation
export function validateBlockPosition(position: any): ValidationResult {
  const errors: ValidationError[] = []

  if (!position.blockId || typeof position.blockId !== "string") {
    errors.push({ field: "blockId", message: "Block ID is required" })
  }

  if (!Number.isInteger(position.x) || position.x < 0) {
    errors.push({ field: "x", message: "X coordinate must be a non-negative integer" })
  }

  if (!Number.isInteger(position.y) || position.y < 0) {
    errors.push({ field: "y", message: "Y coordinate must be a non-negative integer" })
  }

  if (!Number.isInteger(position.width) || position.width <= 0) {
    errors.push({ field: "width", message: "Width must be a positive integer" })
  }

  if (!Number.isInteger(position.height) || position.height <= 0) {
    errors.push({ field: "height", message: "Height must be a positive integer" })
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}

// Customer info validation
export function validateCustomerInfo(info: any): ValidationResult {
  const errors: ValidationError[] = []

  if (!info.name || typeof info.name !== "string") {
    errors.push({ field: "name", message: "Customer name is required" })
  }

  if (!info.phone || typeof info.phone !== "string") {
    errors.push({ field: "phone", message: "Phone number is required" })
  }

  if (!info.monthlyPayment || typeof info.monthlyPayment !== "number" || info.monthlyPayment <= 0) {
    errors.push({ field: "monthlyPayment", message: "Monthly payment must be a positive number" })
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}
