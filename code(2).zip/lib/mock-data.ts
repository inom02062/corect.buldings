import type { Block, Apartment, ApartmentStatus } from "./types"

// Generate apartments for a floor
function generateApartments(block: string, floor: number, startNumber: number): Apartment[] {
  const apartments: Apartment[] = []
  const statuses: ApartmentStatus[] = ["bosh", "tolayotganlar", "tolangan"]

  for (let i = 0; i < 10; i++) {
    const apartmentNumber = `${startNumber + i}`
    // Random status distribution
    const randomStatus = statuses[Math.floor(Math.random() * statuses.length)]

    apartments.push({
      id: Number.parseInt(`${block.charCodeAt(0)}${floor}${i}`),
      number: apartmentNumber,
      status: randomStatus,
      owner: randomStatus !== "bosh" ? `Egasi ${apartmentNumber}` : undefined,
      floor,
      block,
    })
  }

  return apartments
}

// Generate all blocks
export function generateBlocks(): Block[] {
  const blocks: Block[] = []
  const blockNames = ["A", "B", "C", "D"]

  blockNames.forEach((blockName) => {
    const floors = []
    let apartmentCounter = 1

    for (let floor = 1; floor <= 10; floor++) {
      floors.push({
        number: floor,
        apartments: generateApartments(blockName, floor, apartmentCounter),
      })
      apartmentCounter += 10
    }

    blocks.push({
      id: blockName,
      name: `Blok ${blockName}`,
      totalFloors: 10,
      totalApartments: 100,
      floors,
    })
  })

  return blocks
}

// Get initial mock data
export const mockBlocks = generateBlocks()
