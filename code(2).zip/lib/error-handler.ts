/**
 * Error handling utilities
 */

export class AppError extends Error {
  constructor(
    public code: string,
    public message: string,
    public statusCode = 500,
    public details?: any,
  ) {
    super(message)
    this.name = "AppError"
  }
}

export class ValidationError extends AppError {
  constructor(
    message: string,
    public errors: any[] = [],
  ) {
    super("VALIDATION_ERROR", message, 400, { errors })
  }
}

export class NotFoundError extends AppError {
  constructor(resource: string) {
    super("NOT_FOUND", `${resource} not found`, 404)
  }
}

export class DatabaseError extends AppError {
  constructor(message: string, details?: any) {
    super("DATABASE_ERROR", message, 500, details)
  }
}

export class AuthenticationError extends AppError {
  constructor(message = "Authentication failed") {
    super("AUTH_ERROR", message, 401)
  }
}

export function handleError(error: unknown): AppError {
  if (error instanceof AppError) {
    return error
  }

  if (error instanceof Error) {
    // Handle Prisma errors
    if ((error as any).code === "P2025") {
      return new NotFoundError("Record")
    }

    if ((error as any).code?.startsWith("P")) {
      return new DatabaseError("Database error: " + error.message, error)
    }

    return new AppError("UNKNOWN_ERROR", error.message, 500)
  }

  return new AppError("UNKNOWN_ERROR", "An unknown error occurred", 500)
}

export function formatErrorResponse(error: AppError) {
  return {
    error: {
      code: error.code,
      message: error.message,
      ...(error.details && { details: error.details }),
    },
  }
}
