"use client"

import * as React from "react"
import type { Language } from "./i18n"
import { getTranslation } from "./i18n"

type LanguageProviderProps = {
  children: React.ReactNode
  defaultLanguage?: Language
}

type LanguageProviderState = {
  language: Language
  setLanguage: (language: Language) => void
  t: (key: string) => string
}

const LanguageProviderContext = React.createContext<LanguageProviderState | undefined>(undefined)

export function LanguageProvider({ children, defaultLanguage = "uz" }: LanguageProviderProps) {
  const [language, setLanguageState] = React.useState<Language>(defaultLanguage)
  const [mounted, setMounted] = React.useState(false)

  React.useEffect(() => {
    setMounted(true)
    try {
      const stored = localStorage.getItem("language") as Language | null
      if (stored && ["uz", "ru", "en"].includes(stored)) {
        setLanguageState(stored)
      }
    } catch (error) {
      console.error("Failed to load language from localStorage:", error)
    }
  }, [])

  const setLanguage = React.useCallback((newLanguage: Language) => {
    setLanguageState(newLanguage)

    if (typeof window !== "undefined") {
      try {
        localStorage.setItem("language", newLanguage)
      } catch (error) {
        console.error("Failed to save language:", error)
      }
    }
  }, [])

  const t = React.useCallback(
    (key: string) => {
      return getTranslation(language, key)
    },
    [language],
  )

  const value = {
    language,
    setLanguage,
    t,
  }

  return <LanguageProviderContext.Provider value={value}>{children}</LanguageProviderContext.Provider>
}

export const useLanguage = () => {
  const context = React.useContext(LanguageProviderContext)

  if (context === undefined) throw new Error("useLanguage must be used within a LanguageProvider")

  return context
}
