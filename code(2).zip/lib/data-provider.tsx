"use client"

import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react"
import type { Block, Apartment } from "./types"
import { generateBlocks } from "./mock-data"

interface DataContextType {
  blocks: Block[]
  updateApartment: (blockId: string, floorNumber: number, apartment: Apartment) => void
  deleteApartment: (blockId: string, floorNumber: number, apartmentId: number) => void
  addApartment: (blockId: string, floorNumber: number, apartment: Apartment) => void
  resetAllApartments: () => void
  createBlock: (name: string, totalFloors: number, totalApartments: number) => Block | null
  deleteBlock: (blockId: string) => void
  loading: boolean
  error: string | null
}

const DataContext = createContext<DataContextType | undefined>(undefined)

const STORAGE_KEY = "building-sales-data"
const USE_DATABASE = false // Set to true when Supabase is connected

export function DataProvider({ children }: { children: ReactNode }) {
  const [blocks, setBlocks] = useState<Block[]>(() => generateBlocks())
  const [mounted, setMounted] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Initialize data from localStorage or database
  useEffect(() => {
    setMounted(true)
    initializeData()
  }, [])

  // Save data to localStorage
  useEffect(() => {
    if (!mounted) return

    if (typeof window !== "undefined" && !USE_DATABASE) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(blocks))
      } catch (err) {
        console.error("Failed to save data to localStorage:", err)
        setError("Failed to save data")
      }
    }
  }, [blocks, mounted])

  const initializeData = async () => {
    try {
      setLoading(true)

      if (USE_DATABASE) {
        const response = await fetch("/api/blocks")
        if (!response.ok) throw new Error("Failed to fetch blocks")
        const dbBlocks = await response.json()
        setBlocks(dbBlocks)
      } else {
        // Fallback to localStorage
        if (typeof window !== "undefined") {
          const stored = localStorage.getItem(STORAGE_KEY)
          if (stored) {
            const parsedData = JSON.parse(stored)
            setBlocks(parsedData)
          }
        }
      }
    } catch (err) {
      console.error("Failed to initialize data:", err)
      setError("Failed to load data. Using local storage.")
    } finally {
      setLoading(false)
    }
  }

  const updateApartment = useCallback((blockId: string, floorNumber: number, updatedApartment: Apartment) => {
    setBlocks((prevBlocks) =>
      prevBlocks.map((block) => {
        if (block.id !== blockId) return block

        return {
          ...block,
          floors: block.floors.map((floor) => {
            if (floor.number !== floorNumber) return floor

            return {
              ...floor,
              apartments: floor.apartments.map((apt) => (apt.id === updatedApartment.id ? updatedApartment : apt)),
            }
          }),
        }
      }),
    )

    if (USE_DATABASE) {
      fetch(`/api/apartments/${updatedApartment.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedApartment),
      }).catch((err) => console.error("Failed to update apartment in database:", err))
    }
  }, [])

  const deleteApartment = useCallback((blockId: string, floorNumber: number, apartmentId: number) => {
    setBlocks((prevBlocks) =>
      prevBlocks.map((block) => {
        if (block.id !== blockId) return block

        return {
          ...block,
          floors: block.floors.map((floor) => {
            if (floor.number !== floorNumber) return floor

            return {
              ...floor,
              apartments: floor.apartments.filter((apt) => apt.id !== apartmentId),
            }
          }),
        }
      }),
    )

    if (USE_DATABASE) {
      fetch(`/api/apartments/${apartmentId}`, {
        method: "DELETE",
      }).catch((err) => console.error("Failed to delete apartment from database:", err))
    }
  }, [])

  const addApartment = useCallback((blockId: string, floorNumber: number, newApartment: Apartment) => {
    setBlocks((prevBlocks) =>
      prevBlocks.map((block) => {
        if (block.id !== blockId) return block

        return {
          ...block,
          floors: block.floors.map((floor) => {
            if (floor.number !== floorNumber) return floor

            return {
              ...floor,
              apartments: [...floor.apartments, newApartment],
            }
          }),
        }
      }),
    )

    if (USE_DATABASE) {
      fetch("/api/apartments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newApartment),
      }).catch((err) => console.error("Failed to add apartment to database:", err))
    }
  }, [])

  const resetAllApartments = useCallback(() => {
    setBlocks((prevBlocks) =>
      prevBlocks.map((block) => ({
        ...block,
        floors: block.floors.map((floor) => ({
          ...floor,
          apartments: floor.apartments.map((apt) => ({
            ...apt,
            status: "bosh" as const,
            customerInfo: undefined,
            owner: undefined,
          })),
        })),
      })),
    )
  }, [])

  const createBlock = useCallback((name: string, totalFloors: number, totalApartments: number): Block | null => {
    const newBlock: Block = {
      id: `block-${Date.now()}`,
      name,
      totalFloors,
      totalApartments,
      floors: Array.from({ length: totalFloors }, (_, i) => ({
        number: i + 1,
        apartments: Array.from({ length: Math.ceil(totalApartments / totalFloors) }, (_, j) => ({
          id: Date.now() + j,
          number: `${i + 1}${String(j + 1).padStart(2, "0")}`,
          status: "bosh" as const,
          floor: i + 1,
          block: name,
        })),
      })),
    }
    setBlocks((prev) => [...prev, newBlock])

    if (USE_DATABASE) {
      fetch("/api/blocks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newBlock),
      }).catch((err) => console.error("Failed to create block in database:", err))
    }

    return newBlock
  }, [])

  const deleteBlock = useCallback((blockId: string) => {
    setBlocks((prev) => prev.filter((b) => b.id !== blockId))

    if (USE_DATABASE) {
      fetch(`/api/blocks/${blockId}`, {
        method: "DELETE",
      }).catch((err) => console.error("Failed to delete block from database:", err))
    }
  }, [])

  return (
    <DataContext.Provider
      value={{
        blocks,
        updateApartment,
        deleteApartment,
        addApartment,
        resetAllApartments,
        createBlock,
        deleteBlock,
        loading,
        error,
      }}
    >
      {children}
    </DataContext.Provider>
  )
}

export function useData() {
  const context = useContext(DataContext)
  if (context === undefined) {
    throw new Error("useData must be used within a DataProvider")
  }
  return context
}
