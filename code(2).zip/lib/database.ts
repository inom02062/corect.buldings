// APARTMENTS
export async function getApartments() {
  try {
    const response = await fetch("/api/apartments")
    return response.json()
  } catch (error) {
    console.error("Failed to fetch apartments:", error)
    return []
  }
}

export async function getApartment(id: number) {
  try {
    const response = await fetch(`/api/apartments/${id}`)
    return response.json()
  } catch (error) {
    console.error("Failed to fetch apartment:", error)
    return null
  }
}

export async function updateApartment(id: number, data: any) {
  try {
    const response = await fetch(`/api/apartments/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
    return response.json()
  } catch (error) {
    console.error("Failed to update apartment:", error)
    return null
  }
}

export async function deleteApartment(id: number) {
  try {
    const response = await fetch(`/api/apartments/${id}`, {
      method: "DELETE",
    })
    return response.json()
  } catch (error) {
    console.error("Failed to delete apartment:", error)
    return null
  }
}

// BLOCKS
export async function getBlocks() {
  try {
    const response = await fetch("/api/blocks")
    return response.json()
  } catch (error) {
    console.error("Failed to fetch blocks:", error)
    return []
  }
}

export async function getBlock(id: string) {
  try {
    const response = await fetch(`/api/blocks/${id}`)
    return response.json()
  } catch (error) {
    console.error("Failed to fetch block:", error)
    return null
  }
}

export async function updateBlock(id: string, data: any) {
  try {
    const response = await fetch(`/api/blocks/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    })
    return response.json()
  } catch (error) {
    console.error("Failed to update block:", error)
    return null
  }
}

export async function deleteBlock(id: string) {
  try {
    const response = await fetch(`/api/blocks/${id}`, {
      method: "DELETE",
    })
    return response.json()
  } catch (error) {
    console.error("Failed to delete block:", error)
    return null
  }
}

// MAPS
export async function getMaps() {
  try {
    const response = await fetch("/api/maps")
    return response.json()
  } catch (error) {
    console.error("Failed to fetch maps:", error)
    return []
  }
}
