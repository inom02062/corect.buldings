import { BlockFloorsClient } from "@/components/block-floors-client"

export default async function BlockFloorsPage({
  params,
}: {
  params: Promise<{ blockId: string }>
}) {
  const { blockId } = await params

  return <BlockFloorsClient blockId={blockId} />
}
