import { FloorApartmentsClient } from "@/components/floor-apartments-client"

export default async function FloorApartmentsPage({
  params,
}: {
  params: Promise<{ blockId: string; floorNumber: string }>
}) {
  const { blockId, floorNumber } = await params

  return <FloorApartmentsClient blockId={blockId} floorNumber={floorNumber} />
}
