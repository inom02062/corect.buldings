"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Plus, Calendar, DollarSign, CreditCard } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useLanguage } from "@/lib/language-provider"

export default function RentalPage() {
  const router = useRouter()
  const { t } = useLanguage()
  const [rentals, setRentals] = useState<any[]>([])
  const [showForm, setShowForm] = useState(false)

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="flex">
        {/* Sidebar */}
        <div className="hidden md:flex flex-col w-64 bg-card border-r border-border/30 p-6 h-screen sticky top-0">
          <button
            onClick={() => router.push("/")}
            className="flex items-center gap-2 mb-8 text-accent hover:text-accent/80"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium">{t("back")}</span>
          </button>

          <h2 className="text-xl font-bold mb-6">{t("rental")}</h2>

          <nav className="space-y-2">
            <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-accent/10 text-accent">
              <CreditCard className="w-5 h-5" />
              <span>{t("rentalPayments")}</span>
            </button>
            <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-foreground/70 hover:bg-muted">
              <Calendar className="w-5 h-5" />
              <span>{t("rentalAgreement")}</span>
            </button>
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6 lg:p-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">{t("rental")}</h1>
              <p className="text-muted-foreground">{t("rentalPayments")}</p>
            </div>
            <Button onClick={() => setShowForm(!showForm)} className="gap-2 rounded-xl bg-accent hover:bg-accent/90">
              <Plus className="w-5 h-5" />
              {t("addPayment")}
            </Button>
          </div>

          {showForm && (
            <Card className="card-telegram p-6 mb-8">
              <h2 className="text-xl font-bold mb-4">{t("addPayment")}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input placeholder={t("rentalAmount")} type="number" className="rounded-xl" />
                <Input placeholder={t("paymentDate")} type="date" className="rounded-xl" />
                <Input placeholder={t("rentalDuration")} type="text" className="rounded-xl" />
                <Input placeholder={t("paymentStatus")} type="text" className="rounded-xl" />
              </div>
              <div className="flex gap-3 mt-6">
                <Button className="flex-1 rounded-xl bg-accent hover:bg-accent/90">{t("saveChanges")}</Button>
                <Button
                  variant="outline"
                  className="flex-1 rounded-xl bg-transparent"
                  onClick={() => setShowForm(false)}
                >
                  {t("cancel")}
                </Button>
              </div>
            </Card>
          )}

          <div className="grid gap-4">
            {rentals.length === 0 ? (
              <Card className="card-telegram p-8 text-center">
                <p className="text-muted-foreground">{t("rentalHistory")} - Hech qanday ijara yo'q</p>
              </Card>
            ) : (
              rentals.map((rental, idx) => (
                <Card key={idx} className="card-telegram p-5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <DollarSign className="w-6 h-6 text-accent" />
                      <div>
                        <h3 className="font-semibold">{rental.amount}</h3>
                        <p className="text-sm text-muted-foreground">{rental.date}</p>
                      </div>
                    </div>
                    <span className="px-3 py-1 rounded-lg bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-sm font-medium">
                      {t("paid")}
                    </span>
                  </div>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
