"use client"

import { useMemo } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Home, Building2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useData } from "@/lib/data-provider"
import { useLanguage } from "@/lib/language-provider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Apartment } from "@/lib/types"

interface ApartmentWithLocation extends Apartment {
  blockName: string
  floorNumber: number
}

export default function ApartmentsListPage() {
  const router = useRouter()
  const { t } = useLanguage()
  const { blocks } = useData()

  const { emptyApartments, occupiedApartments, paidApartments, lateApartments } = useMemo(() => {
    const empty: ApartmentWithLocation[] = []
    const occupied: ApartmentWithLocation[] = []
    const paid: ApartmentWithLocation[] = []
    const late: ApartmentWithLocation[] = []

    blocks.forEach((block) => {
      block.floors.forEach((floor) => {
        floor.apartments.forEach((apartment) => {
          const aptWithLocation: ApartmentWithLocation = {
            ...apartment,
            blockName: block.name,
            floorNumber: floor.number,
          }

          if (apartment.status === "bosh") {
            empty.push(aptWithLocation)
          } else if (apartment.status === "tolangan") {
            paid.push(aptWithLocation)
          } else if (apartment.status === "kechikayotgan") {
            late.push(aptWithLocation)
          } else {
            occupied.push(aptWithLocation)
          }
        })
      })
    })

    return { emptyApartments: empty, occupiedApartments: occupied, paidApartments: paid, lateApartments: late }
  }, [blocks])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "bosh":
        return "bg-gray-600 text-white"
      case "tolayotganlar":
        return "bg-blue-600 text-white"
      case "tolangan":
        return "bg-green-600 text-white"
      case "tolanmagan":
        return "bg-orange-600 text-white"
      case "kechikayotgan":
        return "bg-yellow-500 text-black"
      default:
        return "bg-gray-600 text-white"
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "bosh":
        return t("empty")
      case "tolayotganlar":
        return t("occupiedPaying")
      case "tolangan":
        return t("fullyPaid")
      case "tolanmagan":
        return t("occupiedUnpaid")
      case "kechikayotgan":
        return t("latePaying")
      default:
        return status
    }
  }

  const renderApartmentCard = (apartment: ApartmentWithLocation) => (
    <Card
      key={`${apartment.blockName}-${apartment.floorNumber}-${apartment.id}`}
      className="p-3 sm:p-4 bg-card border-border"
    >
      <div className="flex items-start justify-between mb-2 gap-2">
        <div className="min-w-0 flex-1">
          <h3 className="font-semibold text-base sm:text-lg truncate">
            {t("apartmentTitle")} {apartment.number}
          </h3>
          <p className="text-xs sm:text-sm text-muted-foreground flex items-center gap-1">
            <Building2 className="w-3 h-3 sm:w-4 sm:h-4 flex-shrink-0" />
            <span className="truncate">
              {apartment.blockName} • {apartment.floorNumber}-{t("floor")}
            </span>
          </p>
        </div>
        <div
          className={`px-2 py-1 rounded text-xs font-medium whitespace-nowrap flex-shrink-0 ${getStatusColor(apartment.status)}`}
        >
          {getStatusLabel(apartment.status)}
        </div>
      </div>
      {apartment.customerInfo && (
        <div className="mt-3 pt-3 border-t border-border">
          <p className="font-medium text-sm sm:text-base truncate">{apartment.customerInfo.name}</p>
          <p className="text-xs sm:text-sm text-muted-foreground truncate">{apartment.customerInfo.phone}</p>
          {apartment.customerInfo.monthlyPayment && (
            <p className="text-xs sm:text-sm text-muted-foreground mt-1">
              {apartment.customerInfo.monthlyPayment.toLocaleString()} so'm
            </p>
          )}
        </div>
      )}
    </Card>
  )

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-4 sm:py-8">
        <div className="flex items-center justify-between mb-6 sm:mb-8 gap-2">
          <Button variant="ghost" onClick={() => router.push("/")} className="gap-1 sm:gap-2 px-2 sm:px-4">
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">{t("back")}</span>
          </Button>
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-center flex-1">{t("apartmentList")}</h1>
          <Button variant="ghost" onClick={() => router.push("/")} className="gap-1 sm:gap-2 px-2 sm:px-4">
            <Home className="w-4 h-4" />
            <span className="hidden sm:inline">{t("backToHome")}</span>
          </Button>
        </div>

        <Tabs defaultValue="empty" className="w-full">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 mb-4 sm:mb-6 h-auto">
            <TabsTrigger value="empty" className="gap-1 text-xs sm:text-sm py-2">
              <span className="hidden sm:inline">{t("emptyApartments")}</span>
              <span className="sm:hidden">Bo'sh</span>
              <span className="ml-1">({emptyApartments.length})</span>
            </TabsTrigger>
            <TabsTrigger value="occupied" className="gap-1 text-xs sm:text-sm py-2">
              <span className="hidden sm:inline">{t("occupiedApartments")}</span>
              <span className="sm:hidden">To'layotgan</span>
              <span className="ml-1">({occupiedApartments.length})</span>
            </TabsTrigger>
            <TabsTrigger value="late" className="gap-1 text-xs sm:text-sm py-2">
              <span className="hidden sm:inline">{t("lateApartments")}</span>
              <span className="sm:hidden">Kechikkan</span>
              <span className="ml-1">({lateApartments.length})</span>
            </TabsTrigger>
            <TabsTrigger value="paid" className="gap-1 text-xs sm:text-sm py-2">
              <span className="hidden sm:inline">{t("paidApartments")}</span>
              <span className="sm:hidden">To'langan</span>
              <span className="ml-1">({paidApartments.length})</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="empty">
            {emptyApartments.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                {emptyApartments.map(renderApartmentCard)}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground text-base sm:text-lg">{t("noApartmentsFound")}</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="occupied">
            {occupiedApartments.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                {occupiedApartments.map(renderApartmentCard)}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground text-base sm:text-lg">{t("noApartmentsFound")}</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="late">
            {lateApartments.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                {lateApartments.map(renderApartmentCard)}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground text-base sm:text-lg">{t("noApartmentsFound")}</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="paid">
            {paidApartments.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                {paidApartments.map(renderApartmentCard)}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground text-base sm:text-lg">{t("noApartmentsFound")}</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
