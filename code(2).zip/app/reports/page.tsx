"use client"

import { ProtectedRoute } from "@/components/protected-route"
import { useData } from "@/lib/data-provider"
import { calculateBuildingStats } from "@/lib/building-utils"
import { Card } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { ChartContainer, ChartTooltip } from "@/components/ui/chart"
import { useLanguage } from "@/lib/language-provider"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"
import { ExportButton } from "@/components/export-button"
import { prepareExportData } from "@/lib/export-utils"

export default function ReportsPage() {
  const { blocks } = useData()
  const { t } = useLanguage()
  const router = useRouter()

  const stats = calculateBuildingStats(blocks)
  const exportData = prepareExportData(blocks, stats)

  // Bloklar bo'yicha ma'lumotlar
  const blockData = blocks.map((block) => {
    let occupied = 0,
      available = 0,
      paid = 0

    block.floors.forEach((floor) => {
      floor.apartments.forEach((apt) => {
        if (apt.status === "bosh") available++
        else if (apt.status === "tolangan") paid++
        else occupied++
      })
    })

    return {
      name: block.name,
      occupied,
      available,
      paid,
    }
  })

  const statusData = [
    { name: "Bo'sh", value: stats.available, color: "#d1d5db" },
    { name: "Obunachilar", value: stats.occupied, color: "#dc2626" },
    { name: "To'langanlari", value: stats.paid, color: "#16a34a" },
    { name: "Kechikayotgan", value: stats.late, color: "#eab308" },
  ]

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-background text-foreground">
        <div className="max-w-6xl mx-auto p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => router.back()} className="rounded-lg hover:bg-muted">
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-3xl font-bold">Analitika va Hisobotlar</h1>
                <p className="text-muted-foreground">Bino boshqaruvi statistikasi va tahlillar</p>
              </div>
            </div>
            <ExportButton />
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <Card className="card-telegram p-6">
              <div className="text-muted-foreground text-sm mb-2">Jami Kvartiralar</div>
              <div className="text-3xl font-bold text-foreground">{stats.totalApartments}</div>
              <div className="text-xs text-muted-foreground mt-2">Barcha kvartiralar</div>
            </Card>
            <Card className="card-telegram p-6">
              <div className="text-muted-foreground text-sm mb-2">Obunachilar</div>
              <div className="text-3xl font-bold text-red-500">{stats.occupied}</div>
              <div className="text-xs text-muted-foreground mt-2">
                {stats.totalApartments > 0 ? ((stats.occupied / stats.totalApartments) * 100).toFixed(1) : "0"}%
              </div>
            </Card>
            <Card className="card-telegram p-6">
              <div className="text-muted-foreground text-sm mb-2">To'langanlari</div>
              <div className="text-3xl font-bold text-green-500">{stats.paid}</div>
              <div className="text-xs text-muted-foreground mt-2">
                {stats.totalApartments > 0 ? ((stats.paid / stats.totalApartments) * 100).toFixed(1) : "0"}%
              </div>
            </Card>
            <Card className="card-telegram p-6">
              <div className="text-muted-foreground text-sm mb-2">Kechikayotgan</div>
              <div className="text-3xl font-bold text-yellow-500">{stats.late}</div>
              <div className="text-xs text-muted-foreground mt-2">
                {stats.totalApartments > 0 ? ((stats.late / stats.totalApartments) * 100).toFixed(1) : "0"}%
              </div>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Kvartiralar Holati - Pie Chart */}
            <Card className="card-telegram p-6">
              <h2 className="text-xl font-semibold mb-6">Kvartiralar Holati</h2>
              <ChartContainer
                config={{
                  status: { label: "Status", color: "hsl(var(--chart-1))" },
                }}
                className="h-[300px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={statusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {statusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <ChartTooltip />
                  </PieChart>
                </ResponsiveContainer>
              </ChartContainer>
            </Card>

            {/* Bloklar Bo'yicha Statistika - Bar Chart */}
            <Card className="card-telegram p-6">
              <h2 className="text-xl font-semibold mb-6">Bloklar Bo'yicha Analiz</h2>
              <ChartContainer
                config={{
                  occupied: { label: "Obunachilar", color: "hsl(var(--chart-2))" },
                  available: { label: "Bo'sh", color: "hsl(var(--chart-1))" },
                  paid: { label: "To'langanlari", color: "hsl(var(--chart-3))" },
                }}
                className="h-[300px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={blockData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                    <YAxis stroke="hsl(var(--muted-foreground))" />
                    <Tooltip content={<ChartTooltip />} />
                    <Legend />
                    <Bar dataKey="occupied" fill="rgb(220, 38, 38)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="available" fill="rgb(209, 213, 219)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="paid" fill="rgb(34, 197, 94)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </Card>
          </div>

          {/* Jadval */}
          <Card className="card-telegram p-6 mt-8">
            <h2 className="text-xl font-semibold mb-6">Bloklar Jadval</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border/30">
                    <th className="text-left py-3 px-4 font-semibold">Blok nomi</th>
                    <th className="text-center py-3 px-4 font-semibold">Jami Kvartiralar</th>
                    <th className="text-center py-3 px-4 font-semibold">Obunachilar</th>
                    <th className="text-center py-3 px-4 font-semibold">To'langanlari</th>
                    <th className="text-center py-3 px-4 font-semibold">Bo'sh</th>
                  </tr>
                </thead>
                <tbody>
                  {exportData.blocks.map((block, index) => (
                    <tr key={index} className="border-b border-border/30 hover:bg-muted/50 transition-colors">
                      <td className="py-3 px-4">{block.name}</td>
                      <td className="text-center py-3 px-4 font-medium">{block.totalApartments}</td>
                      <td className="text-center py-3 px-4 text-red-500">{block.occupied}</td>
                      <td className="text-center py-3 px-4 text-green-500">{block.paid}</td>
                      <td className="text-center py-3 px-4 text-gray-500">{block.available}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </div>
    </ProtectedRoute>
  )
}
