"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Plus, UsersIcon, Edit2, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useLanguage } from "@/lib/language-provider"

export default function UsersPage() {
  const router = useRouter()
  const { t } = useLanguage()
  const [users, setUsers] = useState<any[]>([])
  const [showForm, setShowForm] = useState(false)

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="flex">
        {/* Sidebar */}
        <div className="hidden md:flex flex-col w-64 bg-card border-r border-border/30 p-6 h-screen sticky top-0">
          <button
            onClick={() => router.push("/")}
            className="flex items-center gap-2 mb-8 text-accent hover:text-accent/80"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium">{t("back")}</span>
          </button>

          <h2 className="text-xl font-bold mb-6">{t("users")}</h2>

          <nav className="space-y-2">
            <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-accent/10 text-accent">
              <UsersIcon className="w-5 h-5" />
              <span>{t("userManagement")}</span>
            </button>
            <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-foreground/70 hover:bg-muted">
              <UsersIcon className="w-5 h-5" />
              <span>{t("activityLog")}</span>
            </button>
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6 lg:p-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">{t("users")}</h1>
              <p className="text-muted-foreground">{t("userManagement")}</p>
            </div>
            <Button onClick={() => setShowForm(!showForm)} className="gap-2 rounded-xl bg-accent hover:bg-accent/90">
              <Plus className="w-5 h-5" />
              {t("addUser")}
            </Button>
          </div>

          {showForm && (
            <Card className="card-telegram p-6 mb-8">
              <h2 className="text-xl font-bold mb-4">{t("addUser")}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input placeholder={t("username")} className="rounded-xl" />
                <Input placeholder={t("email")} type="email" className="rounded-xl" />
                <Input placeholder={t("userRole")} className="rounded-xl" />
                <Input placeholder={t("status")} className="rounded-xl" />
              </div>
              <div className="flex gap-3 mt-6">
                <Button className="flex-1 rounded-xl bg-accent hover:bg-accent/90">{t("saveChanges")}</Button>
                <Button
                  variant="outline"
                  className="flex-1 rounded-xl bg-transparent"
                  onClick={() => setShowForm(false)}
                >
                  {t("cancel")}
                </Button>
              </div>
            </Card>
          )}

          <div className="grid gap-4">
            {users.length === 0 ? (
              <Card className="card-telegram p-8 text-center">
                <p className="text-muted-foreground">{t("userManagement")} - Hech qanday foydalanuvchi yo'q</p>
              </Card>
            ) : (
              users.map((user, idx) => (
                <Card key={idx} className="card-telegram p-5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                        <UsersIcon className="w-6 h-6 text-accent" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{user.username}</h3>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="sm">
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
