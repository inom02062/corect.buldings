import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma-client"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const apartment = await prisma.apartment.findUnique({
      where: { id: Number.parseInt(params.id) },
      include: {
        customerInfo: true,
        paymentHistory: true,
      },
    })
    return NextResponse.json(apartment)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch apartment" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const apartment = await prisma.apartment.update({
      where: { id: Number.parseInt(params.id) },
      data: body,
    })
    return NextResponse.json(apartment)
  } catch (error) {
    return NextResponse.json({ error: "Failed to update apartment" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await prisma.apartment.delete({
      where: { id: Number.parseInt(params.id) },
    })
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: "Failed to delete apartment" }, { status: 500 })
  }
}
