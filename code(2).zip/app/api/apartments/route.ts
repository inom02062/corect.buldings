import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma-client"
import { validateApartment } from "@/lib/validation"
import { handleError, formatErrorResponse } from "@/lib/error-handler"

export async function GET(request: NextRequest) {
  try {
    const apartments = await prisma.apartment.findMany({
      include: {
        customerInfo: true,
        paymentHistory: true,
      },
    })
    return NextResponse.json(apartments)
  } catch (error) {
    const appError = handleError(error)
    return NextResponse.json(formatErrorResponse(appError), { status: appError.statusCode })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const validation = validateApartment(body)
    if (!validation.valid) {
      return NextResponse.json({ error: "Validation failed", errors: validation.errors }, { status: 400 })
    }

    const apartment = await prisma.apartment.create({
      data: body,
    })
    return NextResponse.json(apartment, { status: 201 })
  } catch (error) {
    const appError = handleError(error)
    return NextResponse.json(formatErrorResponse(appError), { status: appError.statusCode })
  }
}
