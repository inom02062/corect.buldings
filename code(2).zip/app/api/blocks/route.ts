import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma-client"
import { validateBlock } from "@/lib/validation"
import { handleError, formatErrorResponse } from "@/lib/error-handler"

export async function GET(request: NextRequest) {
  try {
    const blocks = await prisma.block.findMany({
      include: {
        floors: {
          include: {
            apartments: true,
          },
        },
      },
    })
    return NextResponse.json(blocks)
  } catch (error) {
    const appError = handleError(error)
    return NextResponse.json(formatErrorResponse(appError), { status: appError.statusCode })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    const validation = validateBlock(body)
    if (!validation.valid) {
      return NextResponse.json({ error: "Validation failed", errors: validation.errors }, { status: 400 })
    }

    const block = await prisma.block.create({
      data: body,
    })
    return NextResponse.json(block, { status: 201 })
  } catch (error) {
    const appError = handleError(error)
    return NextResponse.json(formatErrorResponse(appError), { status: appError.statusCode })
  }
}
