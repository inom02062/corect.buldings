import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma-client"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const block = await prisma.block.findUnique({
      where: { id: params.id },
      include: {
        floors: {
          include: {
            apartments: true,
          },
        },
      },
    })
    return NextResponse.json(block)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch block" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const block = await prisma.block.update({
      where: { id: params.id },
      data: body,
    })
    return NextResponse.json(block)
  } catch (error) {
    return NextResponse.json({ error: "Failed to update block" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await prisma.block.delete({
      where: { id: params.id },
    })
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: "Failed to delete block" }, { status: 500 })
  }
}
