import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma-client"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const map = await prisma.blockMap.findUnique({
      where: { id: params.id },
      include: {
        block: true,
      },
    })
    return NextResponse.json(map)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch map" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const map = await prisma.blockMap.update({
      where: { id: params.id },
      data: body,
    })
    return NextResponse.json(map)
  } catch (error) {
    return NextResponse.json({ error: "Failed to update map" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await prisma.blockMap.delete({
      where: { id: params.id },
    })
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: "Failed to delete map" }, { status: 500 })
  }
}
