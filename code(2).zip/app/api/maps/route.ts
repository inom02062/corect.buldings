import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma-client"

export async function GET(request: NextRequest) {
  try {
    const maps = await prisma.blockMap.findMany({
      include: {
        block: true,
      },
    })
    return NextResponse.json(maps)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch maps" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const map = await prisma.blockMap.create({
      data: body,
    })
    return NextResponse.json(map, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create map" }, { status: 500 })
  }
}
