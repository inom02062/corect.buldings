"use client"

import type React from "react"
import type { BlockPosition } from "@/types/block-position"
import { useState, useRef, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useMap } from "@/lib/map-provider"
import { useData } from "@/lib/data-provider"
import { useLanguage } from "@/lib/language-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Plus, Trash2, ArrowLeft, ZoomIn, ZoomOut, RotateCcw } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

interface DragState {
  blockId: string
  startX: number
  startY: number
  startLeft: number
  startTop: number
  startWidth: number
  startHeight: number
}

interface ResizeState {
  blockId: string
  startX: number
  startY: number
  startWidth: number
  startHeight: number
}

interface PanState {
  startX: number
  startY: number
  startPanX: number
  startPanY: number
}

const GRID_SIZE = 10 // Grid alignment size in pixels
const BORDER_RADIUS_OPTIONS = [
  { value: "rounded-none", label: "0px" },
  { value: "rounded-sm", label: "2px" },
  { value: "rounded-md", label: "6px" },
  { value: "rounded-lg", label: "8px" },
  { value: "rounded-xl", label: "12px" },
  { value: "rounded-2xl", label: "16px" },
  { value: "rounded-3xl", label: "24px" },
]

export default function MapPage() {
  const router = useRouter()
  const { t } = useLanguage()
  const { blocks, createBlock, deleteBlock } = useData()
  const {
    maps,
    currentMapId,
    createMap,
    deleteMap,
    setCurrentMap,
    addBlockToMap,
    removeBlockFromMap,
    getCurrentMap,
    updateBlockPosition,
  } = useMap()
  const [newMapName, setNewMapName] = useState("")
  const [showNewMapInput, setShowNewMapInput] = useState(false)
  const [selectedBlockId, setSelectedBlockId] = useState<string | null>(null)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null)
  const [deleteTargetType, setDeleteTargetType] = useState<"map" | "block">("map")
  const [showCreateBlockDialog, setShowCreateBlockDialog] = useState(false)
  const [newBlockName, setNewBlockName] = useState("")
  const [newBlockFloors, setNewBlockFloors] = useState("5")
  const [newBlockApartments, setNewBlockApartments] = useState("20")
  const [dragState, setDragState] = useState<DragState | null>(null)
  const [resizeState, setResizeState] = useState<ResizeState | null>(null)
  const [zoom, setZoom] = useState(1)
  const [panX, setPanX] = useState(0)
  const [panY, setPanY] = useState(0)
  const [panState, setPanState] = useState<PanState | null>(null)
  const [showGuides, setShowGuides] = useState(false)
  const [alignmentGuides, setAlignmentGuides] = useState<{ x: number[]; y: number[] }>({ x: [], y: [] })
  const canvasRef = useRef<HTMLDivElement>(null)
  const [blockBorderRadius, setBlockBorderRadius] = useState("rounded-lg")
  const currentMap = getCurrentMap()

  useEffect(() => {
    const savedRadius = localStorage.getItem("blockBorderRadius")
    if (savedRadius) {
      setBlockBorderRadius(savedRadius)
    }
  }, [])

  const handleBorderRadiusChange = (radius: string) => {
    setBlockBorderRadius(radius)
    localStorage.setItem("blockBorderRadius", radius)
  }

  const findFreePosition = (existingBlocks: BlockPosition[]): { x: number; y: number } => {
    const blockWidth = 150
    const blockHeight = 100
    const padding = 20
    const gridSize = blockWidth + padding

    for (let row = 0; row < 10; row++) {
      for (let col = 0; col < 10; col++) {
        const x = col * gridSize
        const y = row * gridSize
        const newBlock = { x, y, width: blockWidth, height: blockHeight }
        const hasCollision = existingBlocks.some((block) => checkCollision(newBlock, block))

        if (!hasCollision) {
          return { x, y }
        }
      }
    }

    return { x: Math.random() * 500, y: Math.random() * 500 }
  }

  const checkCollision = (block1: BlockPosition, block2: BlockPosition): boolean => {
    const padding = 10
    return !(
      block1.x + block1.width + padding < block2.x ||
      block2.x + block2.width + padding < block1.x ||
      block1.y + block1.height + padding < block2.y ||
      block2.y + block2.height + padding < block1.y
    )
  }

  const getMagneticSnap = (
    movingBlock: BlockPosition,
    otherBlocks: BlockPosition[],
    snapDistance: number,
  ): { x: number; y: number } => {
    let snappedX = movingBlock.x
    let snappedY = movingBlock.y

    otherBlocks.forEach((block) => {
      // Left edge to right edge
      if (Math.abs(movingBlock.x - (block.x + block.width)) < snapDistance) {
        snappedX = block.x + block.width
        setShowGuides(true)
      }
      // Right edge to left edge
      if (Math.abs(movingBlock.x + movingBlock.width - block.x) < snapDistance) {
        snappedX = block.x - movingBlock.width
        setShowGuides(true)
      }
      // Center to center X alignment
      const movingCenterX = movingBlock.x + movingBlock.width / 2
      const blockCenterX = block.x + block.width / 2
      if (Math.abs(movingCenterX - blockCenterX) < snapDistance) {
        snappedX = blockCenterX - movingBlock.width / 2
        setShowGuides(true)
      }

      // Top edge to bottom edge
      if (Math.abs(movingBlock.y - (block.y + block.height)) < snapDistance) {
        snappedY = block.y + block.height
        setShowGuides(true)
      }
      // Bottom edge to top edge
      if (Math.abs(movingBlock.y + movingBlock.height - block.y) < snapDistance) {
        snappedY = block.y - movingBlock.height
        setShowGuides(true)
      }
      // Center to center Y alignment
      const movingCenterY = movingBlock.y + movingBlock.height / 2
      const blockCenterY = block.y + block.height / 2
      if (Math.abs(movingCenterY - blockCenterY) < snapDistance) {
        snappedY = blockCenterY - movingBlock.height / 2
        setShowGuides(true)
      }
    })

    return { x: snappedX, y: snappedY }
  }

  const alignBlocksToGrid = () => {
    if (!currentMapId || !currentMap) return

    const alignedBlocks = currentMap.blocks.map((block) => {
      const alignedX = Math.round(block.x / GRID_SIZE) * GRID_SIZE
      const alignedY = Math.round(block.y / GRID_SIZE) * GRID_SIZE
      return { ...block, x: alignedX, y: alignedY }
    })

    alignedBlocks.forEach((block) => {
      updateBlockPosition(currentMapId, block.blockId, block.x, block.y, block.width, block.height)
    })
  }

  const handleCreateMap = () => {
    if (newMapName.trim()) {
      createMap(newMapName)
      setNewMapName("")
      setShowNewMapInput(false)
    }
  }

  const handleAddBlockToMap = (blockId: string) => {
    if (!currentMapId) return

    const existingBlock = currentMap?.blocks.find((b) => b.blockId === blockId)
    if (existingBlock) return

    const newPosition = findFreePosition(currentMap?.blocks || [])
    addBlockToMap(currentMapId, {
      blockId,
      x: newPosition.x,
      y: newPosition.y,
      width: 150,
      height: 100,
    })
  }

  const handleRemoveBlock = (blockId: string) => {
    if (!currentMapId) return
    removeBlockFromMap(currentMapId, blockId)
  }

  const handleCreateNewBlock = () => {
    if (!newBlockName.trim()) return

    const floors = Number.parseInt(newBlockFloors) || 5
    const apartments = Number.parseInt(newBlockApartments) || 20

    const newBlock = createBlock(newBlockName, floors, apartments)
    if (newBlock && currentMapId) {
      addBlockToMap(currentMapId, {
        blockId: newBlock.id,
        x: Math.random() * 200,
        y: Math.random() * 200,
        width: 150,
        height: 100,
      })
    }

    setNewBlockName("")
    setNewBlockFloors("5")
    setNewBlockApartments("20")
    setShowCreateBlockDialog(false)
  }

  const handleDeleteMap = (mapId: string) => {
    setDeleteTargetId(mapId)
    setDeleteTargetType("map")
    setShowDeleteDialog(true)
  }

  const handleDeleteBlock = (blockId: string) => {
    setDeleteTargetId(blockId)
    setDeleteTargetType("block")
    setShowDeleteDialog(true)
  }

  const confirmDelete = () => {
    if (!deleteTargetId) return

    if (deleteTargetType === "map") {
      deleteMap(deleteTargetId)
    } else {
      deleteBlock(deleteTargetId)
      if (currentMapId) {
        removeBlockFromMap(currentMapId, deleteTargetId)
      }
    }

    setShowDeleteDialog(false)
    setDeleteTargetId(null)
  }

  const handleBlockMouseDown = (e: React.MouseEvent, blockId: string) => {
    if ((e.target as HTMLElement).closest(".resize-handle")) {
      return
    }

    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const blockPos = currentMap?.blocks.find((b) => b.blockId === blockId)
    if (!blockPos) return

    setDragState({
      blockId,
      startX: e.clientX,
      startY: e.clientY,
      startLeft: blockPos.x,
      startTop: blockPos.y,
      startWidth: blockPos.width,
      startHeight: blockPos.height,
    })
  }

  const handleBlockDoubleClick = (blockId: string) => {
    router.push(`/block/${blockId}`)
  }

  const handleResizeMouseDown = (e: React.MouseEvent, blockId: string) => {
    e.stopPropagation()
    const blockPos = currentMap?.blocks.find((b) => b.blockId === blockId)
    if (!blockPos) return

    setResizeState({
      blockId,
      startX: e.clientX,
      startY: e.clientY,
      startWidth: blockPos.width,
      startHeight: blockPos.height,
    })
  }

  const handleCanvasMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest(".block-item")) {
      return
    }
    if (e.button !== 0 && e.button !== 1 && e.button !== 2) return

    setPanState({
      startX: e.clientX,
      startY: e.clientY,
      startPanX: panX,
      startPanY: panY,
    })
  }

  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev + 0.2, 3))
  }

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev - 0.2, 0.5))
  }

  const handleResetZoom = () => {
    setZoom(1)
    setPanX(0)
    setPanY(0)
  }

  const handleCanvasWheel = (e: React.WheelEvent) => {
    e.preventDefault()
    if (e.deltaY < 0) {
      handleZoomIn()
    } else {
      handleZoomOut()
    }
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!currentMapId) return

    if (panState) {
      const deltaX = e.clientX - panState.startX
      const deltaY = e.clientY - panState.startY
      setPanX(panState.startPanX + deltaX / zoom)
      setPanY(panState.startPanY + deltaY / zoom)
      return
    }

    if (dragState) {
      const deltaX = e.clientX - dragState.startX
      const deltaY = e.clientY - dragState.startY

      let newX = dragState.startLeft + deltaX / zoom
      let newY = dragState.startTop + deltaY / zoom

      const snappedPos = getMagneticSnap(
        { x: newX, y: newY, width: dragState.startWidth, height: dragState.startHeight },
        currentMap?.blocks.filter((b) => b.blockId !== dragState.blockId) || [],
        25, // Increased from 15 to 25 pixels for better magnetic attraction
      )

      newX = snappedPos.x
      newY = snappedPos.y

      const otherBlocks = currentMap?.blocks.filter((b) => b.blockId !== dragState.blockId) || []
      const xLines: number[] = []
      const yLines: number[] = []

      otherBlocks.forEach((block) => {
        // Check all edge and center alignments
        if (Math.abs(newX - (block.x + block.width)) < 20) xLines.push(block.x + block.width)
        if (Math.abs(newX + dragState.startWidth - block.x) < 20) xLines.push(block.x)
        if (Math.abs(newX + dragState.startWidth / 2 - (block.x + block.width / 2)) < 20) {
          xLines.push(block.x + block.width / 2)
        }

        if (Math.abs(newY - (block.y + block.height)) < 20) yLines.push(block.y + block.height)
        if (Math.abs(newY + dragState.startHeight - block.y) < 20) yLines.push(block.y)
        if (Math.abs(newY + dragState.startHeight / 2 - (block.y + block.height / 2)) < 20) {
          yLines.push(block.y + block.height / 2)
        }
      })

      setAlignmentGuides({ x: xLines, y: yLines })
      setShowGuides(xLines.length > 0 || yLines.length > 0)

      updateBlockPosition(currentMapId, dragState.blockId, newX, newY, dragState.startWidth, dragState.startHeight)
    }

    if (resizeState) {
      const deltaX = e.clientX - resizeState.startX
      const deltaY = e.clientY - resizeState.startY

      const newWidth = Math.max(80, resizeState.startWidth + deltaX / zoom)
      const newHeight = Math.max(60, resizeState.startHeight + deltaY / zoom)

      updateBlockPosition(
        currentMapId,
        resizeState.blockId,
        currentMap?.blocks.find((b) => b.blockId === resizeState.blockId)?.x || 0,
        currentMap?.blocks.find((b) => b.blockId === resizeState.blockId)?.y || 0,
        newWidth,
        newHeight,
      )
    }
  }

  const handleMouseUp = () => {
    setDragState(null)
    setResizeState(null)
    setPanState(null)
    setShowGuides(false)
  }

  return (
    <div className="min-h-screen bg-background text-foreground" onMouseMove={handleMouseMove} onMouseUp={handleMouseUp}>
      <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-6 py-4 sm:py-6 lg:py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 sm:mb-8">
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm" onClick={() => router.back()} className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">{t("back")}</span>
            </Button>
            <div>
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold">{t("mapTitle")}</h1>
              <p className="text-sm sm:text-base text-muted-foreground">{t("mapSubtitle")}</p>
            </div>
          </div>
        </div>

        <div className="mb-6 p-4 bg-secondary rounded-lg border border-border">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-sm font-medium text-foreground">Blok burchagi radiusi:</span>
            <div className="flex gap-2 flex-wrap">
              {BORDER_RADIUS_OPTIONS.map((option) => (
                <Button
                  key={option.value}
                  size="sm"
                  variant={blockBorderRadius === option.value ? "default" : "outline"}
                  onClick={() => handleBorderRadiusChange(option.value)}
                  className="text-xs h-8"
                >
                  {option.label}
                </Button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 sm:gap-6">
          {/* Sidebar - Maps List */}
          <div className="lg:col-span-1">
            <Card className="p-4 bg-card border-border">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold">{t("maps")}</h2>
                <Button size="sm" onClick={() => setShowNewMapInput(!showNewMapInput)} className="gap-1 h-8">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>

              {showNewMapInput && (
                <div className="mb-4 flex gap-2">
                  <Input
                    placeholder={t("mapName")}
                    value={newMapName}
                    onChange={(e) => setNewMapName(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleCreateMap()}
                    className="text-sm"
                  />
                  <Button size="sm" onClick={handleCreateMap} className="h-8">
                    OK
                  </Button>
                </div>
              )}

              <div className="space-y-2">
                {maps.map((map) => (
                  <div
                    key={map.id}
                    className={`p-3 rounded-lg cursor-pointer transition-colors ${
                      currentMapId === map.id
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary hover:bg-secondary/80 text-secondary-foreground"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <button onClick={() => setCurrentMap(map.id)} className="flex-1 text-left text-sm font-medium">
                        {map.name}
                      </button>
                      {maps.length > 1 && (
                        <button onClick={() => handleDeleteMap(map.id)} className="p-1 hover:bg-red-600/20 rounded">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                    <p className="text-xs opacity-75 mt-1">
                      {map.blocks.length} {t("block")}
                    </p>
                  </div>
                ))}
              </div>
            </Card>

            {/* Available Blocks */}
            <Card className="p-4 bg-card border-border mt-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">{t("availableBlocks")}</h3>
                <Button
                  size="sm"
                  onClick={() => setShowCreateBlockDialog(true)}
                  className="gap-1 h-8"
                  title={t("createNewBlock")}
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="space-y-2">
                {blocks.map((block) => {
                  const isInMap = currentMap?.blocks.some((b) => b.blockId === block.id)
                  return (
                    <div
                      key={block.id}
                      className="p-3 rounded-lg bg-secondary/50 flex items-center justify-between gap-2"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium truncate">{block.name}</div>
                        <div className="text-xs text-muted-foreground">
                          {block.totalApartments} {t("apartment")}
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant={isInMap ? "destructive" : "default"}
                          onClick={() => (isInMap ? handleRemoveBlock(block.id) : handleAddBlockToMap(block.id))}
                          className="h-7 text-xs"
                        >
                          {isInMap ? t("remove") : t("add")}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDeleteBlock(block.id)}
                          className="h-7 text-xs text-red-500 hover:text-red-400"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  )
                })}
              </div>
            </Card>
          </div>

          {/* Canvas - Map Visualization */}
          <div className="lg:col-span-3">
            <Card className="p-4 bg-card border-border min-h-[500px] sm:min-h-[600px]">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold">
                  {currentMap?.name || t("mapTitle")} - {currentMap?.blocks.length || 0} {t("block")}
                </h2>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={handleZoomIn} title={t("zoomIn")}>
                    <ZoomIn className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="outline" onClick={handleZoomOut} title={t("zoomOut")}>
                    <ZoomOut className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="outline" onClick={handleResetZoom} title={t("reset")}>
                    <RotateCcw className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={alignBlocksToGrid}
                    title="Bloklarni X va Y o'qlari bo'ylab shunga ravshan qilish"
                  >
                    ⊞
                  </Button>
                  <span className="text-sm text-muted-foreground px-2 py-1">{Math.round(zoom * 100)}%</span>
                </div>
              </div>
              <div
                ref={canvasRef}
                className="relative w-full h-[400px] sm:h-[500px] bg-secondary/20 rounded-lg border-2 border-dashed border-border overflow-hidden cursor-grab active:cursor-grabbing"
                onMouseDown={handleCanvasMouseDown}
                onWheel={handleCanvasWheel}
                style={{ touchAction: "none" }}
              >
                <div
                  style={{
                    transform: `scale(${zoom}) translate(${panX}px, ${panY}px)`,
                    transformOrigin: "0 0",
                    transition: panState ? "none" : "transform 0.1s ease-out",
                  }}
                >
                  {showGuides && (
                    <>
                      {alignmentGuides.x.map((xPos, idx) => (
                        <div
                          key={`guide-x-${idx}`}
                          className="absolute top-0 bottom-0 w-0.5 bg-blue-400/50 pointer-events-none"
                          style={{ left: `${xPos}px` }}
                        />
                      ))}
                      {alignmentGuides.y.map((yPos, idx) => (
                        <div
                          key={`guide-y-${idx}`}
                          className="absolute left-0 right-0 h-0.5 bg-blue-400/50 pointer-events-none"
                          style={{ top: `${yPos}px` }}
                        />
                      ))}
                    </>
                  )}

                  {currentMap && currentMap.blocks.length > 0 ? (
                    currentMap.blocks.map((blockPos) => {
                      const block = blocks.find((b) => b.id === blockPos.blockId)
                      const isSelected = selectedBlockId === blockPos.blockId
                      return (
                        <div
                          key={blockPos.blockId}
                          className={`block-item absolute bg-blue-500/80 hover:bg-blue-600 text-white ${blockBorderRadius} p-3 cursor-move transition-colors shadow-lg ${
                            isSelected ? "ring-2 ring-blue-300" : ""
                          }`}
                          style={{
                            left: `${blockPos.x}px`,
                            top: `${blockPos.y}px`,
                            width: `${blockPos.width}px`,
                            height: `${blockPos.height}px`,
                            userSelect: "none",
                          }}
                          onMouseDown={(e) => handleBlockMouseDown(e, blockPos.blockId)}
                          onClick={() => setSelectedBlockId(blockPos.blockId)}
                          onDoubleClick={() => handleBlockDoubleClick(blockPos.blockId)}
                        >
                          <div className="text-sm font-semibold truncate">{block?.name}</div>
                          <div className="text-xs opacity-90">
                            {block?.totalApartments} {t("apartment")} • {block?.totalFloors} {t("floor")}
                          </div>
                          <div
                            className="resize-handle absolute bottom-0 right-0 w-5 h-5 bg-amber-100/90 hover:bg-amber-200 rounded-full cursor-se-resize shadow-md border-2 border-amber-300 transition-colors flex items-center justify-center"
                            onMouseDown={(e) => handleResizeMouseDown(e, blockPos.blockId)}
                            title="Hajmini o'zgartirish uchun suring"
                          >
                            <span className="text-xs text-amber-800">⋮⋮</span>
                          </div>
                        </div>
                      )
                    })
                  ) : (
                    <div className="flex items-center justify-center h-full text-muted-foreground">
                      <p className="text-center">{t("hint")}</p>
                    </div>
                  )}
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                💡 {t("dragHint")} | ⊞ Bloklarni X va Y o'qlari bo'ylab to'g'rilash uchun tugmani bosing
              </p>
            </Card>
          </div>
        </div>
      </div>

      <Dialog open={showCreateBlockDialog} onOpenChange={setShowCreateBlockDialog}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-foreground">{t("createBlock")}</DialogTitle>
            <DialogDescription className="text-muted-foreground">{t("mapSubtitle")}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-2 block">{t("blockName")}</label>
              <Input
                placeholder={t("blockName")}
                value={newBlockName}
                onChange={(e) => setNewBlockName(e.target.value)}
                className="bg-secondary text-foreground border-border"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">{t("floorsCount")}</label>
                <Input
                  type="number"
                  min="1"
                  max="50"
                  value={newBlockFloors}
                  onChange={(e) => setNewBlockFloors(e.target.value)}
                  className="bg-secondary text-foreground border-border"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">{t("apartmentsCount")}</label>
                <Input
                  type="number"
                  min="1"
                  max="500"
                  value={newBlockApartments}
                  onChange={(e) => setNewBlockApartments(e.target.value)}
                  className="bg-secondary text-foreground border-border"
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateBlockDialog(false)} className="border-border">
              {t("cancel")}
            </Button>
            <Button onClick={handleCreateNewBlock} className="bg-primary hover:bg-primary/90">
              {t("createBlock")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent className="bg-card border-border">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-foreground">
              {deleteTargetType === "map" ? t("deleteMap") : t("deleteBlock")}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground">
              {deleteTargetType === "map" ? t("confirmDeleteMap") : t("confirmDeleteBlock")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-secondary text-secondary-foreground hover:bg-secondary/80">
              {t("cancel")}
            </AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700 text-white">
              {t("delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
