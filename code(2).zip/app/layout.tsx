import type React from "react"
import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { GeistMono } from "geist/font/mono"
import { Suspense } from "react"
import { ThemeProvider } from "@/lib/theme-provider"
import { LanguageProvider } from "@/lib/language-provider"
import { DataProvider } from "@/lib/data-provider"
import { MapProvider } from "@/lib/map-provider"
import { AuthProvider } from "@/lib/auth-context"
import "./globals.css"

export const metadata: Metadata = {
  title: "Binolar Sotish Tizimi",
  description: "Binolar Sotish Boshqaruv Tizimi",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="uz" suppressHydrationWarning>
      <body className={`font-sans ${GeistSans.variable} ${GeistMono.variable}`}>
        <ThemeProvider defaultTheme="dark">
          <AuthProvider>
            <LanguageProvider defaultLanguage="uz">
              <DataProvider>
                <MapProvider>
                  <Suspense fallback={null}>{children}</Suspense>
                </MapProvider>
              </DataProvider>
            </LanguageProvider>
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
