"use client"

import { Card } from "@/components/ui/card"
import type { Apartment } from "@/lib/types"
import { getStatusColor, getStatusLabel } from "@/lib/building-utils"
import { cn } from "@/lib/utils"

interface ApartmentCardProps {
  apartment: Apartment
  onClick?: () => void
}

export function ApartmentCard({ apartment, onClick }: ApartmentCardProps) {
  const statusColor = getStatusColor(apartment.status)
  const statusLabel = getStatusLabel(apartment.status)

  const shouldGlow = apartment.status === "bosh" || apartment.status === "kechikayotgan"
  const glowColor =
    apartment.status === "bosh" ? "shadow-[0_0_15px_rgba(156,163,175,0.5)]" : "shadow-[0_0_15px_rgba(234,179,8,0.6)]"

  return (
    <Card
      className={cn(
        "p-6 border-gray-700 cursor-pointer transition-all hover:scale-105",
        statusColor,
        shouldGlow && glowColor,
      )}
      onClick={onClick}
    >
      <div className="text-center">
        <div className="text-2xl font-bold text-white mb-1">{apartment.number}</div>
        {apartment.owner && apartment.status !== "bosh" && (
          <div className="text-xs text-white/80">{apartment.owner}</div>
        )}
      </div>
    </Card>
  )
}
