"use client"

import { useState } from "react"
import { FileText, Download, FileJson, BarChart3 } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { useData } from "@/lib/data-provider"
import { calculateBuildingStats } from "@/lib/building-utils"
import { prepareExportData, downloadCSV } from "@/lib/export-utils"
import { downloadPDF } from "@/lib/pdf-export"
import { useLanguage } from "@/lib/language-provider"

export function ExportButton() {
  const { blocks } = useData()
  const { t } = useLanguage()
  const [isLoading, setIsLoading] = useState(false)

  const stats = calculateBuildingStats(blocks)
  const exportData = prepareExportData(blocks, stats)

  const handleExportCSV = () => {
    setIsLoading(true)
    try {
      downloadCSV(exportData)
    } finally {
      setIsLoading(false)
    }
  }

  const handleExportPDF = async () => {
    setIsLoading(true)
    try {
      await downloadPDF(exportData)
      setTimeout(() => setIsLoading(false), 1000)
    } catch (error) {
      console.error("[v0] PDF export failed:", error)
      setIsLoading(false)
      alert("PDF yuklab olib bo'lmadi. Tekshirib ko'ring.")
    }
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className="gap-2 border-border/30 bg-card hover:bg-muted"
          disabled={isLoading}
        >
          <Download className="w-4 h-4" />
          Yuklab olish
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56 bg-card border-border rounded-xl">
        <DropdownMenuLabel className="text-foreground">Hisobot formatini tanlang</DropdownMenuLabel>
        <DropdownMenuSeparator className="bg-border/30" />

        <DropdownMenuItem
          onClick={handleExportCSV}
          disabled={isLoading}
          className="gap-2 cursor-pointer text-foreground hover:bg-muted focus:bg-muted"
        >
          <FileJson className="w-4 h-4 text-blue-500" />
          <div>
            <div className="font-medium">Excel (CSV)</div>
            <div className="text-xs text-muted-foreground">Microsoft Excel formatida</div>
          </div>
        </DropdownMenuItem>

        <DropdownMenuItem
          onClick={handleExportPDF}
          disabled={isLoading}
          className="gap-2 cursor-pointer text-foreground hover:bg-muted focus:bg-muted"
        >
          <FileText className="w-4 h-4 text-red-500" />
          <div>
            <div className="font-medium">PDF</div>
            <div className="text-xs text-muted-foreground">PDF formatida to'liq hisobot</div>
          </div>
        </DropdownMenuItem>

        <DropdownMenuSeparator className="bg-border/30" />

        <DropdownMenuItem disabled className="gap-2 text-foreground text-xs">
          <BarChart3 className="w-4 h-4 text-green-500" />
          <span className="text-muted-foreground">JSON (Tez orada)</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
