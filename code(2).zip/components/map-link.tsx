"use client"

import { Button } from "@/components/ui/button"
import { Map } from "lucide-react"
import { useRouter } from "next/navigation"

export function MapLink() {
  const router = useRouter()

  return (
    <Button variant="outline" onClick={() => router.push("/map")} className="gap-2 text-xs sm:text-sm h-8">
      <Map className="w-3 h-3 sm:w-4 sm:h-4" />
      <span className="hidden sm:inline">Xarita</span>
      <span className="sm:hidden">Xarita</span>
    </Button>
  )
}
