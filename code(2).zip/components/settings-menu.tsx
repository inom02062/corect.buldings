"use client"

import { Settings, Moon, Sun, Languages, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { useTheme } from "@/lib/theme-provider"
import { useLanguage } from "@/lib/language-provider"
import { useData } from "@/lib/data-provider"
import { useState } from "react"
import type { Language } from "@/lib/i18n"

export function SettingsMenu() {
  const { theme, setTheme } = useTheme()
  const { language, setLanguage, t } = useLanguage()
  const { resetAllApartments } = useData()
  const [showResetDialog, setShowResetDialog] = useState(false)

  const handleReset = () => {
    resetAllApartments()
    setShowResetDialog(false)
  }

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="icon" className="border-border bg-card hover:bg-accent">
            <Settings className="h-5 w-5" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56 bg-card border-border">
          <DropdownMenuLabel className="text-foreground">{t("settings")}</DropdownMenuLabel>
          <DropdownMenuSeparator className="bg-border" />

          <DropdownMenuLabel className="text-sm text-muted-foreground">{t("theme")}</DropdownMenuLabel>
          <DropdownMenuItem
            onClick={() => setTheme("light")}
            className="hover:bg-accent text-foreground cursor-pointer"
          >
            <Sun className="mr-2 h-4 w-4" />
            <span>{t("light")}</span>
            {theme === "light" && <span className="ml-auto">✓</span>}
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setTheme("dark")} className="hover:bg-accent text-foreground cursor-pointer">
            <Moon className="mr-2 h-4 w-4" />
            <span>{t("dark")}</span>
            {theme === "dark" && <span className="ml-auto">✓</span>}
          </DropdownMenuItem>

          <DropdownMenuSeparator className="bg-border" />
          <DropdownMenuLabel className="text-sm text-muted-foreground">{t("language")}</DropdownMenuLabel>
          <DropdownMenuItem
            onClick={() => setLanguage("uz")}
            className="hover:bg-accent text-foreground cursor-pointer"
          >
            <Languages className="mr-2 h-4 w-4" />
            <span>O'zbekcha</span>
            {language === "uz" && <span className="ml-auto">✓</span>}
          </DropdownMenuItem>
          <DropdownMenuItem
            onClick={() => setLanguage("ru")}
            className="hover:bg-accent text-foreground cursor-pointer"
          >
            <Languages className="mr-2 h-4 w-4" />
            <span>Русский</span>
            {language === "ru" && <span className="ml-auto">✓</span>}
          </DropdownMenuItem>
          <DropdownMenuItem
            onClick={() => setLanguage("en" as Language)}
            className="hover:bg-accent text-foreground cursor-pointer"
          >
            <Languages className="mr-2 h-4 w-4" />
            <span>English</span>
            {language === "en" && <span className="ml-auto">✓</span>}
          </DropdownMenuItem>

          <DropdownMenuSeparator className="bg-border" />
          <DropdownMenuItem
            onClick={() => setShowResetDialog(true)}
            className="hover:bg-accent text-red-500 hover:text-red-400 cursor-pointer"
          >
            <RotateCcw className="mr-2 h-4 w-4" />
            <span>{t("resetAllApartments")}</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <AlertDialog open={showResetDialog} onOpenChange={setShowResetDialog}>
        <AlertDialogContent className="bg-card border-border">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-foreground">{t("resetAllApartments")}</AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground">{t("confirmReset")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-secondary text-secondary-foreground hover:bg-secondary/80">
              {t("cancel")}
            </AlertDialogCancel>
            <AlertDialogAction onClick={handleReset} className="bg-red-600 hover:bg-red-700 text-white">
              {t("resetAllApartments")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
