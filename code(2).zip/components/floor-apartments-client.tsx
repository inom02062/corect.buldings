"use client"

import { useState } from "react"
import { ArrowLeft, Search, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ApartmentCard } from "@/components/apartment-card"
import { ApartmentDialog } from "@/components/apartment-dialog"
import { FilterBar } from "@/components/filter-bar"
import { useData } from "@/lib/data-provider"
import { useLanguage } from "@/lib/language-provider"
import type { Apartment, ApartmentStatus } from "@/lib/types"
import Link from "next/link"

interface FloorApartmentsClientProps {
  blockId: string
  floorNumber: string
}

export function FloorApartmentsClient({ blockId, floorNumber }: FloorApartmentsClientProps) {
  const { blocks, updateApartment, deleteApartment, addApartment } = useData()
  const { t } = useLanguage()

  const block = blocks.find((b) => b.id === blockId)
  const floor = block?.floors.find((f) => f.number === Number.parseInt(floorNumber))

  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<ApartmentStatus | "all">("all")
  const [selectedApartment, setSelectedApartment] = useState<Apartment | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)

  if (!block || !floor) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">{t("floorNotFound")}</h1>
          <Link href="/">
            <Button>{t("backToHome")}</Button>
          </Link>
        </div>
      </div>
    )
  }

  const filteredApartments = floor.apartments.filter((apt) => {
    const matchesSearch =
      apt.number.toLowerCase().includes(searchQuery.toLowerCase()) ||
      apt.owner?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      apt.customerInfo?.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      apt.customerInfo?.phone.includes(searchQuery)

    const matchesStatus = statusFilter === "all" || apt.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const handleApartmentClick = (apartment: Apartment) => {
    const freshApartment = floor.apartments.find((apt) => apt.id === apartment.id) || apartment
    setSelectedApartment(freshApartment)
    setDialogOpen(true)
  }

  const handleSaveApartment = (updatedApartment: Apartment) => {
    updateApartment(blockId, Number.parseInt(floorNumber), updatedApartment)
  }

  const handleDeleteApartment = (apartmentToDelete: Apartment) => {
    deleteApartment(blockId, Number.parseInt(floorNumber), apartmentToDelete.id)
    setDialogOpen(false)
  }

  const handleAddApartment = () => {
    const maxNumber = Math.max(...floor.apartments.map((apt) => Number.parseInt(apt.number)))
    const newApartment: Apartment = {
      id: Date.now(),
      number: String(maxNumber + 1),
      status: "bosh",
      floor: Number.parseInt(floorNumber),
      block: blockId,
    }
    addApartment(blockId, Number.parseInt(floorNumber), newApartment)
  }

  const currentSelectedApartment = selectedApartment
    ? floor.apartments.find((apt) => apt.id === selectedApartment.id) || selectedApartment
    : null

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-4 sm:py-8">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <Link href={`/block/${blockId}`}>
            <Button variant="outline" className="mb-4 bg-transparent text-xs sm:text-sm">
              <ArrowLeft className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              {t("back")}
            </Button>
          </Link>
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold">
            {t("block")} {blockId} - {floorNumber}-{t("floor")}
          </h1>
        </div>

        {/* Search and Actions */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-4 mb-4 sm:mb-6">
          <div className="flex-1 relative">
            <Input
              type="text"
              placeholder={t("searchApartment")}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-10 text-sm"
            />
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-muted-foreground" />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1 sm:flex-none text-xs sm:text-sm bg-transparent">
              <Settings className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              {t("floors")}
            </Button>
            <Button onClick={handleAddApartment} className="flex-1 sm:flex-none text-xs sm:text-sm">
              {t("addApartment")}
            </Button>
          </div>
        </div>

        <FilterBar statusFilter={statusFilter} onStatusFilterChange={setStatusFilter} />

        {/* Apartments Count */}
        <div className="mb-4">
          <h2 className="text-base sm:text-xl font-semibold">
            {t("apartments")} ({filteredApartments.length}/{floor.apartments.length})
          </h2>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-10 gap-2 sm:gap-4">
          {filteredApartments.map((apartment) => (
            <ApartmentCard key={apartment.id} apartment={apartment} onClick={() => handleApartmentClick(apartment)} />
          ))}
        </div>

        {filteredApartments.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-sm sm:text-lg">{t("noApartmentsFound")}</p>
          </div>
        )}

        {/* Apartment Dialog */}
        <ApartmentDialog
          apartment={currentSelectedApartment}
          open={dialogOpen}
          onOpenChange={setDialogOpen}
          onSave={handleSaveApartment}
          onDelete={handleDeleteApartment}
        />
      </div>
    </div>
  )
}
