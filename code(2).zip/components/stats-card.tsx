import type React from "react"
import { Card } from "@/components/ui/card"

interface StatsCardProps {
  icon: React.ReactNode
  label: string
  value: number
  percentage?: string
  color: string
}

export function StatsCard({ icon, label, value, percentage, color }: StatsCardProps) {
  return (
    <Card className="p-4 sm:p-5 lg:p-6 rounded-2xl border-border/30 bg-card shadow-sm hover:shadow-md transition-all duration-200">
      <div className="flex items-center gap-2 mb-3">
        <div className={`w-3 h-3 rounded-full ${color} flex-shrink-0`} />
        <span className="text-xs sm:text-sm text-muted-foreground leading-tight">{label}</span>
      </div>
      <div className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground">{value}</div>
      {percentage && <div className="text-xs sm:text-sm text-muted-foreground mt-2">{percentage}</div>}
    </Card>
  )
}
