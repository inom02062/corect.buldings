"use client"

import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { ApartmentStatus } from "@/lib/types"

interface FilterBarProps {
  statusFilter: ApartmentStatus | "all"
  onStatusFilterChange: (status: ApartmentStatus | "all") => void
}

export function FilterBar({ statusFilter, onStatusFilterChange }: FilterBarProps) {
  return (
    <div className="flex items-center gap-4 mb-6">
      <div className="flex items-center gap-2">
        <span className="text-sm text-gray-400">Holati:</span>
        <Select value={statusFilter} onValueChange={onStatusFilterChange}>
          <SelectTrigger className="w-40 bg-gray-800 border-gray-700">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-gray-700 border-gray-600">
            <SelectItem value="all">Hammasi</SelectItem>
            <SelectItem value="bosh">Bo'sh</SelectItem>
            <SelectItem value="band">Band qilingan</SelectItem>
            <SelectItem value="tolangan">To'langan</SelectItem>
            <SelectItem value="tolanmagan">To'lanmagan</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Button
        variant="outline"
        onClick={() => onStatusFilterChange("all")}
        className="bg-gray-800 border-gray-700 hover:bg-gray-700"
      >
        Filterni tozalash
      </Button>
    </div>
  )
}
