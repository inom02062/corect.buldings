"use client"

import type React from "react"

import { useMap } from "@/lib/map-provider"
import { useData } from "@/lib/data-provider"
import { useLanguage } from "@/lib/language-provider"
import { Card } from "@/components/ui/card"
import { useRouter } from "next/navigation"
import { useState, useRef, useEffect } from "react"

export function ReadOnlyMap() {
  const router = useRouter()
  const { t } = useLanguage()
  const { getCurrentMap } = useMap()
  const { blocks } = useData()
  const canvasRef = useRef<HTMLDivElement>(null)
  const [zoom, setZoom] = useState(1)
  const [panX, setPanX] = useState(0)
  const [panY, setPanY] = useState(0)
  const [panState, setPanState] = useState<{
    startX: number
    startY: number
    startPanX: number
    startPanY: number
  } | null>(null)
  const [blockBorderRadius, setBlockBorderRadius] = useState("rounded-lg")

  const currentMap = getCurrentMap()

  useEffect(() => {
    const savedRadius = localStorage.getItem("blockBorderRadius")
    if (savedRadius) {
      setBlockBorderRadius(savedRadius)
    }
  }, [])

  useEffect(() => {
    if (!currentMap || currentMap.blocks.length === 0) {
      setZoom(1)
      setPanX(0)
      setPanY(0)
      return
    }

    const canvas = canvasRef.current
    if (!canvas) return

    const canvasRect = canvas.getBoundingClientRect()
    const canvasWidth = canvasRect.width
    const canvasHeight = canvasRect.height

    let minX = Number.POSITIVE_INFINITY,
      minY = Number.POSITIVE_INFINITY,
      maxX = Number.NEGATIVE_INFINITY,
      maxY = Number.NEGATIVE_INFINITY

    currentMap.blocks.forEach((block) => {
      minX = Math.min(minX, block.x)
      minY = Math.min(minY, block.y)
      maxX = Math.max(maxX, block.x + block.width)
      maxY = Math.max(maxY, block.y + block.height)
    })

    const contentWidth = maxX - minX
    const contentHeight = maxY - minY
    const padding = 40

    const zoomX = (canvasWidth - padding) / contentWidth
    const zoomY = (canvasHeight - padding) / contentHeight
    const newZoom = Math.min(zoomX, zoomY, 1)

    const offsetX = (canvasWidth / newZoom - contentWidth) / 2 - minX
    const offsetY = (canvasHeight / newZoom - contentHeight) / 2 - minY

    setZoom(newZoom)
    setPanX(offsetX)
    setPanY(offsetY)
  }, [currentMap])

  const handleBlockDoubleClick = (blockId: string) => {
    router.push(`/block/${blockId}`)
  }

  const handleCanvasMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest(".block-item")) {
      return
    }
    if (e.button !== 0 && e.button !== 1 && e.button !== 2) return

    setPanState({
      startX: e.clientX,
      startY: e.clientY,
      startPanX: panX,
      startPanY: panY,
    })
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (panState) {
      const deltaX = e.clientX - panState.startX
      const deltaY = e.clientY - panState.startY
      setPanX(panState.startPanX + deltaX / zoom)
      setPanY(panState.startPanY + deltaY / zoom)
    }
  }

  const handleMouseUp = () => {
    setPanState(null)
  }

  if (!currentMap || currentMap.blocks.length === 0) {
    return null
  }

  return (
    <Card className="p-4 sm:p-6 bg-card border-border mb-6 sm:mb-8">
      <h2 className="text-lg sm:text-xl lg:text-2xl font-semibold mb-4">
        {currentMap.name} - {currentMap.blocks.length} {t("block")}
      </h2>
      <div
        ref={canvasRef}
        className="relative w-full h-[300px] sm:h-[400px] bg-secondary/20 rounded-lg border-2 border-dashed border-border overflow-hidden cursor-grab active:cursor-grabbing"
        onMouseDown={handleCanvasMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        style={{ touchAction: "none" }}
      >
        <div
          style={{
            transform: `scale(${zoom}) translate(${panX}px, ${panY}px)`,
            transformOrigin: "0 0",
            transition: panState ? "none" : "transform 0.1s ease-out",
          }}
        >
          {currentMap.blocks.map((blockPos) => {
            const block = blocks.find((b) => b.id === blockPos.blockId)
            return (
              <div
                key={blockPos.blockId}
                className={`block-item absolute bg-blue-500/80 text-white ${blockBorderRadius} p-3 cursor-pointer transition-colors shadow-lg hover:bg-blue-600`}
                style={{
                  left: `${blockPos.x}px`,
                  top: `${blockPos.y}px`,
                  width: `${blockPos.width}px`,
                  height: `${blockPos.height}px`,
                  userSelect: "none",
                }}
                onDoubleClick={() => handleBlockDoubleClick(blockPos.blockId)}
                title="2 marta bosing qavatlari sahifasiga o'tish uchun"
              >
                <div className="text-sm font-semibold truncate">{block?.name}</div>
                <div className="text-xs opacity-90">
                  {block?.totalApartments} {t("apartment")} • {block?.totalFloors} {t("floor")}
                </div>
              </div>
            )
          })}
        </div>
      </div>
      <p className="text-xs sm:text-sm text-muted-foreground mt-3">
        {t("mapEditHint")}
        <button onClick={() => router.push("/map")} className="text-accent hover:underline font-semibold">
          {t("editMap")}
        </button>
        • O'ng tugma bilan suring
      </p>
    </Card>
  )
}
