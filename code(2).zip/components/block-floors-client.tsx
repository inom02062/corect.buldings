"use client"

import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { FloorCard } from "@/components/floor-card"
import { useData } from "@/lib/data-provider"
import Link from "next/link"
import { useLanguage } from "@/lib/language-provider"

export function BlockFloorsClient({ blockId }: { blockId: string }) {
  const { blocks } = useData()
  const { t } = useLanguage()
  const block = blocks.find((b) => b.id === blockId)

  if (!block) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center px-4">
          <h1 className="text-xl sm:text-2xl font-bold mb-4">{t.blockNotFound}</h1>
          <Link href="/">
            <Button>{t.backToHome}</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-4 sm:py-8">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <Link href="/">
            <Button variant="outline" className="mb-4 bg-transparent text-xs sm:text-sm">
              <ArrowLeft className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
              {t.back}
            </Button>
          </Link>
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold">
            {t.block} {blockId}
          </h1>
        </div>

        {/* Floors Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
          {block.floors.map((floor) => (
            <FloorCard
              key={floor.number}
              blockId={blockId}
              floorNumber={floor.number}
              totalApartments={floor.apartments.length}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
