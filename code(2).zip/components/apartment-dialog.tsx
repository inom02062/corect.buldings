"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Trash2, UserPlus, Plus } from "lucide-react"
import type { Apartment, ApartmentStatus, CustomerInfo } from "@/lib/types"
import { Card } from "@/components/ui/card"

interface ApartmentDialogProps {
  apartment: Apartment | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onSave: (apartment: Apartment) => void
  onDelete?: (apartment: Apartment) => void
}

export function ApartmentDialog({ apartment, open, onOpenChange, onSave, onDelete }: ApartmentDialogProps) {
  const [status, setStatus] = useState<ApartmentStatus>("bosh")
  const [customerInfo, setCustomerInfo] = useState<CustomerInfo>({
    name: "",
    phone: "",
    entryDate: "",
    monthlyPayment: 0,
    lastPaymentDate: "",
    paymentHistory: [],
  })
  const [newPayment, setNewPayment] = useState({ month: "", amount: 0, date: "" })
  const [showAddPayment, setShowAddPayment] = useState(false)

  useEffect(() => {
    if (apartment && open) {
      setStatus(apartment.status)
      setCustomerInfo(
        apartment.customerInfo || {
          name: "",
          phone: "",
          entryDate: "",
          monthlyPayment: 0,
          lastPaymentDate: "",
          paymentHistory: [],
        },
      )
    }
  }, [apartment, open])

  if (!apartment) return null

  const handleSave = () => {
    onSave({
      ...apartment,
      status,
      owner: status !== "bosh" ? customerInfo.name : undefined,
      customerInfo: status !== "bosh" ? customerInfo : undefined,
    })
    onOpenChange(false)
  }

  const handleDelete = () => {
    if (onDelete && confirm("Kvartira ma'lumotlarini o'chirmoqchimisiz?")) {
      onDelete(apartment)
    }
  }

  const handleQuickStatusChange = (newStatus: ApartmentStatus) => {
    setStatus(newStatus)
  }

  const getStatusLabel = (status: ApartmentStatus) => {
    switch (status) {
      case "bosh":
        return "Bo'sh"
      case "tolayotganlar":
        return "To'layotganlar"
      case "tolangan":
        return "To'langan"
      case "tolanmagan":
        return "To'lanmagan"
      case "kechikayotgan":
        return "Kechikayotgan"
      default:
        return status
    }
  }

  const getStatusColor = (status: ApartmentStatus) => {
    switch (status) {
      case "bosh":
        return "bg-gray-600"
      case "tolayotganlar":
        return "bg-blue-600"
      case "tolangan":
        return "bg-green-600"
      case "tolanmagan":
        return "bg-orange-600"
      case "kechikayotgan":
        return "bg-yellow-500 text-black"
      default:
        return "bg-gray-600"
    }
  }

  const handleAddPayment = () => {
    if (newPayment.month && newPayment.amount && newPayment.date) {
      const updatedHistory = [...(customerInfo.paymentHistory || []), newPayment]
      setCustomerInfo({
        ...customerInfo,
        paymentHistory: updatedHistory,
        lastPaymentDate: newPayment.date,
      })
      setNewPayment({ month: "", amount: 0, date: "" })
      setShowAddPayment(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-gray-900 border-gray-700 text-white max-w-[95vw] sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle className="text-base sm:text-lg font-semibold">
            Kvartira {apartment.number} - {apartment.floor}-qavat
          </DialogTitle>
          {onDelete && (
            <Button
              variant="destructive"
              size="sm"
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700 text-xs sm:text-sm"
            >
              <Trash2 className="w-3 h-3 sm:w-4 sm:h-4 sm:mr-1" />
              <span className="hidden sm:inline">O'chirish</span>
            </Button>
          )}
        </DialogHeader>

        <div className="space-y-4 py-2">
          <Card className={`p-3 ${getStatusColor(status)} border-0`}>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-white" />
              <span className="font-medium text-sm sm:text-base">Joriy holat: {getStatusLabel(status)}</span>
            </div>
          </Card>

          <div className="space-y-2">
            <Label className="text-xs sm:text-sm font-medium">Tez o'zgartirish</Label>
            <div className="grid grid-cols-2 sm:flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleQuickStatusChange("tolangan")}
                className={`text-xs ${
                  status === "tolangan"
                    ? "bg-green-600 border-green-600 text-white"
                    : "bg-gray-800 border-gray-700 hover:bg-gray-700"
                }`}
              >
                To'langan
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleQuickStatusChange("kechikayotgan")}
                className={`text-xs ${
                  status === "kechikayotgan"
                    ? "bg-yellow-500 border-yellow-500 text-black"
                    : "bg-gray-800 border-gray-700 hover:bg-gray-700"
                }`}
              >
                Kechikkan
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleQuickStatusChange("tolanmagan")}
                className={`text-xs ${
                  status === "tolanmagan"
                    ? "bg-orange-600 border-orange-600 text-white"
                    : "bg-gray-800 border-gray-700 hover:bg-gray-700"
                }`}
              >
                To'lanmagan
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleQuickStatusChange("bosh")}
                className={`text-xs ${
                  status === "bosh"
                    ? "bg-gray-600 border-gray-600 text-white"
                    : "bg-gray-800 border-gray-700 hover:bg-gray-700"
                }`}
              >
                Bo'sh
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="status" className="text-xs sm:text-sm font-medium">
              Batafsil status
            </Label>
            <Select value={status} onValueChange={(v) => setStatus(v as ApartmentStatus)}>
              <SelectTrigger className="bg-gray-800 border-gray-700 text-white text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-700 text-white">
                <SelectItem value="bosh">Bo'sh</SelectItem>
                <SelectItem value="tolayotganlar">To'layotganlar</SelectItem>
                <SelectItem value="kechikayotgan">Kechikayotgan</SelectItem>
                <SelectItem value="tolangan">To'langan</SelectItem>
                <SelectItem value="tolanmagan">To'lanmagan</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {status !== "bosh" && (
            <>
              <div className="flex items-center justify-between pt-2">
                <Label className="text-xs sm:text-sm font-medium">Mijoz ma'lumotlari</Label>
                <Button variant="outline" size="sm" className="bg-gray-800 border-gray-700 hover:bg-gray-700 text-xs">
                  <UserPlus className="w-3 h-3 mr-1" />
                  <span className="hidden sm:inline">Mijoz qo'shish</span>
                </Button>
              </div>

              <div className="space-y-3">
                <div className="space-y-1.5">
                  <Label htmlFor="customerName" className="text-xs sm:text-sm">
                    Mijoz ismi
                  </Label>
                  <Input
                    id="customerName"
                    value={customerInfo.name}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, name: e.target.value })}
                    placeholder="To'liq ism"
                    className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500 text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="phone" className="text-xs sm:text-sm">
                    Telefon raqam
                  </Label>
                  <Input
                    id="phone"
                    value={customerInfo.phone}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, phone: e.target.value })}
                    placeholder="+998901234567"
                    className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500 text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="entryDate" className="text-xs sm:text-sm">
                    Kirish sanasi
                  </Label>
                  <Input
                    id="entryDate"
                    type="date"
                    value={customerInfo.entryDate}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, entryDate: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="monthlyPayment" className="text-xs sm:text-sm">
                    Oylik to'lov (so'm)
                  </Label>
                  <Input
                    id="monthlyPayment"
                    type="number"
                    value={customerInfo.monthlyPayment || ""}
                    onChange={(e) =>
                      setCustomerInfo({ ...customerInfo, monthlyPayment: Number.parseInt(e.target.value) || 0 })
                    }
                    placeholder="2000000"
                    className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500 text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="lastPaymentDate" className="text-xs sm:text-sm">
                    Oxirgi to'lov sanasi
                  </Label>
                  <Input
                    id="lastPaymentDate"
                    type="date"
                    value={customerInfo.lastPaymentDate || ""}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, lastPaymentDate: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white text-sm"
                  />
                </div>
              </div>

              {status === "tolangan" && customerInfo.paymentHistory && customerInfo.paymentHistory.length > 0 && (
                <div className="space-y-2">
                  <Label className="text-xs sm:text-sm font-medium">To'lov tarixi</Label>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {customerInfo.paymentHistory.map((payment, index) => (
                      <Card key={index} className="p-2 bg-gray-800 border-gray-700">
                        <div className="flex justify-between items-center text-xs">
                          <div>
                            <p className="font-medium">{payment.month}</p>
                            <p className="text-gray-400">{payment.date}</p>
                          </div>
                          <p className="font-semibold text-green-400">{payment.amount.toLocaleString()} so'm</p>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {status !== "tolangan" &&
                (status === "tolayotganlar" || status === "kechikayotgan" || status === "tolanmagan") && (
                  <div className="space-y-2">
                    {!showAddPayment ? (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowAddPayment(true)}
                        className="w-full bg-gray-800 border-gray-700 hover:bg-gray-700 text-xs"
                      >
                        <Plus className="w-3 h-3 mr-1" />
                        To'lov qo'shish
                      </Button>
                    ) : (
                      <div className="space-y-2 p-3 bg-gray-800 rounded-lg border border-gray-700">
                        <div className="space-y-1.5">
                          <Label htmlFor="paymentMonth" className="text-xs">
                            Oy (YYYY-MM)
                          </Label>
                          <Input
                            id="paymentMonth"
                            type="month"
                            value={newPayment.month}
                            onChange={(e) => setNewPayment({ ...newPayment, month: e.target.value })}
                            className="bg-gray-900 border-gray-600 text-white text-sm"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="paymentAmount" className="text-xs">
                            Summa (so'm)
                          </Label>
                          <Input
                            id="paymentAmount"
                            type="number"
                            value={newPayment.amount || ""}
                            onChange={(e) =>
                              setNewPayment({ ...newPayment, amount: Number.parseInt(e.target.value) || 0 })
                            }
                            className="bg-gray-900 border-gray-600 text-white text-sm"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="paymentDate" className="text-xs">
                            To'lov sanasi
                          </Label>
                          <Input
                            id="paymentDate"
                            type="date"
                            value={newPayment.date}
                            onChange={(e) => setNewPayment({ ...newPayment, date: e.target.value })}
                            className="bg-gray-900 border-gray-600 text-white text-sm"
                          />
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setShowAddPayment(false)
                              setNewPayment({ month: "", amount: 0, date: "" })
                            }}
                            className="flex-1 bg-gray-900 border-gray-600 hover:bg-gray-800 text-xs"
                          >
                            Bekor qilish
                          </Button>
                          <Button
                            size="sm"
                            onClick={handleAddPayment}
                            className="flex-1 bg-green-600 hover:bg-green-700 text-xs"
                          >
                            Qo'shish
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
            </>
          )}
        </div>

        <div className="flex gap-2 pt-2">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="flex-1 bg-gray-800 border-gray-700 hover:bg-gray-700 text-sm"
          >
            Bekor qilish
          </Button>
          <Button onClick={handleSave} className="flex-1 bg-blue-600 hover:bg-blue-700 text-sm">
            Saqlash
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
