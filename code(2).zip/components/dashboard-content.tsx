"use client"

import { useState, useMemo } from "react"
import { useRouter } from "next/navigation"
import { Search, Moon, Sun, Languages, RotateCcw, TrendingUp, Users, Home, BarChart3, LogOut } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { BlockCard } from "@/components/block-card"
import { useData } from "@/lib/data-provider"
import { useMap } from "@/lib/map-provider"
import { calculateBuildingStats, calculateBlockStats } from "@/lib/building-utils"
import { Card } from "@/components/ui/card"
import { useLanguage } from "@/lib/language-provider"
import { useTheme } from "@/lib/theme-provider"
import { useAuth } from "@/lib/auth-context"
import type { Apartment } from "@/lib/types"
import type { Language } from "@/lib/i18n"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { MapLink } from "@/components/map-link"
import { ReadOnlyMap } from "@/components/read-only-map"
import { ExportButton } from "@/components/export-button" // Assuming ExportButton is imported from this path

export function DashboardContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [showResetDialog, setShowResetDialog] = useState(false)
  const [showLanguageMenu, setShowLanguageMenu] = useState(false)
  const router = useRouter()
  const { t, language, setLanguage } = useLanguage()
  const { theme, setTheme } = useTheme()
  const { user, logout } = useAuth()
  const { blocks, resetAllApartments } = useData()
  const { getCurrentMap } = useMap()
  const currentMap = getCurrentMap()

  const displayedBlocks = useMemo(() => {
    if (!currentMap || currentMap.blocks.length === 0) {
      return blocks
    }
    const mapBlockIds = new Set(currentMap.blocks.map((b) => b.blockId))
    return blocks.filter((b) => mapBlockIds.has(b.id))
  }, [blocks, currentMap])

  const stats = calculateBuildingStats(displayedBlocks)

  const handleReset = () => {
    resetAllApartments()
    setShowResetDialog(false)
  }

  const handleLanguageChange = (newLang: Language) => {
    setLanguage(newLang)
    setShowLanguageMenu(false)
  }

  const handleLogout = () => {
    logout()
    router.push("/login")
  }

  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return []

    const query = searchQuery.toLowerCase()
    const results: Array<{ apartment: Apartment; blockName: string; floorNumber: number }> = []

    displayedBlocks.forEach((block) => {
      block.floors.forEach((floor) => {
        floor.apartments.forEach((apartment) => {
          if (apartment.customerInfo) {
            const nameMatch = apartment.customerInfo.name.toLowerCase().includes(query)
            const phoneMatch = apartment.customerInfo.phone.toLowerCase().includes(query)

            if (nameMatch || phoneMatch) {
              results.push({
                apartment,
                blockName: block.name,
                floorNumber: floor.number,
              })
            }
          }
        })
      })
    })

    return results
  }, [searchQuery, displayedBlocks])

  const chartData = [
    { date: "06/07", occupied: 45, paid: 30, late: 15, available: 10 },
    { date: "07/07", occupied: 52, paid: 35, late: 18, available: 8 },
    { date: "08/07", occupied: 48, paid: 38, late: 12, available: 12 },
    { date: "09/07", occupied: 58, paid: 42, late: 20, available: 6 },
    { date: "10/07", occupied: 42, paid: 45, late: 10, available: 15 },
    { date: "11/07", occupied: 50, paid: 48, late: 16, available: 10 },
    { date: "12/07", occupied: 65, paid: 52, late: 25, available: 5 },
    { date: "13/07", occupied: 55, paid: 55, late: 18, available: 8 },
  ]

  const chartConfig = {
    occupied: {
      label: t("occupied"),
      color: "hsl(var(--chart-2))",
    },
    paid: {
      label: t("paid"),
      color: "hsl(var(--chart-3))",
    },
    late: {
      label: t("late"),
      color: "hsl(var(--chart-4))",
    },
    available: {
      label: t("available"),
      color: "hsl(var(--chart-1))",
    },
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="flex">
        {/* Sidebar Navigation */}
        <div className="hidden md:flex flex-col w-64 bg-card border-r border-border/30 p-6 h-screen sticky top-0">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center">
              <Home className="w-6 h-6 text-accent-foreground" />
            </div>
            <h1 className="text-xl font-bold text-foreground">{t("title")}</h1>
          </div>

          <nav className="space-y-2 flex-1">
            <button
              onClick={() => router.push("/")}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-accent/10 text-accent hover:bg-accent/20 transition-colors"
            >
              <BarChart3 className="w-5 h-5" />
              <span className="font-medium">{t("dashboard")}</span>
            </button>
            <button
              onClick={() => router.push("/apartments")}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-foreground/70 hover:bg-muted transition-colors"
            >
              <Users className="w-5 h-5" />
              <span className="font-medium">{t("apartments")}</span>
            </button>
            <button
              onClick={() => router.push("/map")}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-foreground/70 hover:bg-muted transition-colors"
            >
              <TrendingUp className="w-5 h-5" />
              <span className="font-medium">{t("map")}</span>
            </button>
            <button
              onClick={() => router.push("/rental")}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-foreground/70 hover:bg-muted transition-colors"
            >
              <BarChart3 className="w-5 h-5" />
              <span className="font-medium">{t("rental")}</span>
            </button>
            <button
              onClick={() => router.push("/users")}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-foreground/70 hover:bg-muted transition-colors"
            >
              <Users className="w-5 h-5" />
              <span className="font-medium">{t("users")}</span>
            </button>
            <button
              onClick={() => router.push("/documents")}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-foreground/70 hover:bg-muted transition-colors"
            >
              <BarChart3 className="w-5 h-5" />
              <span className="font-medium">{t("documents")}</span>
            </button>
          </nav>

          {/* User Info Section */}
          <div className="space-y-4 border-t border-border/30 pt-4 mb-4">
            <div className="bg-muted/50 rounded-lg p-3">
              <p className="text-xs text-muted-foreground mb-1">Hozirgi foydalanuvchi:</p>
              <p className="font-semibold text-sm text-foreground capitalize">{user?.username}</p>
              <p className="text-xs text-accent uppercase mt-1">{user?.role}</p>
            </div>
          </div>

          {/* Settings in Sidebar */}
          <div className="space-y-4 border-t border-border/30 pt-4">
            <div className="flex items-center gap-2 bg-muted rounded-xl p-2">
              <Button
                variant={theme === "light" ? "default" : "ghost"}
                size="sm"
                onClick={() => setTheme("light")}
                className="flex-1 h-8 rounded-lg"
              >
                <Sun className="w-4 h-4" />
              </Button>
              <Button
                variant={theme === "dark" ? "default" : "ghost"}
                size="sm"
                onClick={() => setTheme("dark")}
                className="flex-1 h-8 rounded-lg"
              >
                <Moon className="w-4 h-4" />
              </Button>
            </div>

            <div className="relative">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowLanguageMenu(!showLanguageMenu)}
                className="w-full gap-2 justify-start text-sm border-border/30 bg-muted"
              >
                <Languages className="w-4 h-4" />
                {language === "uz" ? "O'zbekcha" : language === "ru" ? "Русский" : "English"}
              </Button>
              {showLanguageMenu && (
                <div className="absolute bottom-full mb-2 left-0 w-full bg-card border border-border rounded-xl shadow-lg overflow-hidden z-50">
                  <button
                    onClick={() => handleLanguageChange("uz")}
                    className="w-full px-4 py-2 text-left text-sm hover:bg-muted text-foreground"
                  >
                    O'zbekcha {language === "uz" && "✓"}
                  </button>
                  <button
                    onClick={() => handleLanguageChange("ru")}
                    className="w-full px-4 py-2 text-left text-sm hover:bg-muted text-foreground"
                  >
                    Русский {language === "ru" && "✓"}
                  </button>
                  <button
                    onClick={() => handleLanguageChange("en")}
                    className="w-full px-4 py-2 text-left text-sm hover:bg-muted text-foreground"
                  >
                    English {language === "en" && "✓"}
                  </button>
                </div>
              )}
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowResetDialog(true)}
              className="w-full gap-2 justify-start text-sm border-red-200/30 text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20"
            >
              <RotateCcw className="w-4 h-4" />
              {t("reset")}
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={handleLogout}
              className="w-full gap-2 justify-start text-sm border-orange-200/30 text-orange-600 dark:text-orange-400 hover:bg-orange-50 dark:hover:bg-orange-950/20 bg-transparent"
            >
              <LogOut className="w-4 h-4" />
              Chiqish
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 px-3 sm:px-4 lg:px-6 py-4 sm:py-6 lg:py-8 overflow-auto">
          <div className="flex md:hidden justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">{t("title")}</h1>
              <p className="text-sm text-muted-foreground">{t("subtitle")}</p>
            </div>
            <MapLink />
          </div>

          {/* Mobile Theme & Language Controls */}
          <div className="md:hidden flex gap-2 mb-6 flex-wrap">
            <div className="flex items-center gap-1 bg-card border border-border rounded-lg p-1">
              <Button
                variant={theme === "light" ? "default" : "ghost"}
                size="sm"
                onClick={() => setTheme("light")}
                className="h-8"
              >
                <Sun className="w-3 h-3" />
              </Button>
              <Button
                variant={theme === "dark" ? "default" : "ghost"}
                size="sm"
                onClick={() => setTheme("dark")}
                className="h-8"
              >
                <Moon className="w-3 h-3" />
              </Button>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="text-xs h-8 border-border bg-card"
              onClick={() => setShowLanguageMenu(!showLanguageMenu)}
            >
              <Languages className="w-3 h-3 mr-1" />
              {language.toUpperCase()}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-xs h-8 text-orange-600 dark:text-orange-400"
              onClick={handleLogout}
            >
              <LogOut className="w-3 h-3" />
            </Button>
          </div>

          {/* Search Bar - Full Width */}
          <div className="mb-6 sm:mb-8">
            <div className="relative">
              <Input
                type="text"
                placeholder={t("searchPlaceholder")}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-card border-border/50 placeholder:text-muted-foreground pr-10 text-sm sm:text-base rounded-2xl py-3"
              />
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            </div>
          </div>

          <div className="flex gap-2 mb-6 sm:mb-8 flex-wrap items-center justify-between">
            <h3 className="text-sm text-muted-foreground">Hisobotlarni yuklab oling</h3>
            <ExportButton />
          </div>

          {/* Search Results */}
          {searchQuery.trim() && searchResults.length > 0 ? (
            <div className="mb-6 sm:mb-8 animate-slide-in">
              <h2 className="text-lg sm:text-xl lg:text-2xl font-semibold mb-4">
                {t("searchResults")} ({searchResults.length})
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {searchResults.map((result, index) => (
                  <Card key={index} className="card-telegram p-4 sm:p-5">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-sm sm:text-base">
                          {t("apartmentTitle")} {result.apartment.number}
                        </h3>
                        <p className="text-xs sm:text-sm text-muted-foreground">
                          {result.blockName} • {result.floorNumber}-{t("floor")}
                        </p>
                      </div>
                      <div
                        className={`px-3 py-1 rounded-lg text-xs font-medium ${
                          result.apartment.status === "bosh"
                            ? "bg-gray-100 dark:bg-gray-900 text-gray-700 dark:text-gray-300"
                            : result.apartment.status === "tolayotganlar"
                              ? "bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400"
                              : result.apartment.status === "tolangan"
                                ? "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400"
                                : result.apartment.status === "kechikayotgan"
                                  ? "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400"
                                  : "bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-400"
                        }`}
                      >
                        {result.apartment.status === "bosh"
                          ? t("empty")
                          : result.apartment.status === "tolayotganlar"
                            ? t("occupiedPaying")
                            : result.apartment.status === "tolangan"
                              ? t("fullyPaid")
                              : result.apartment.status === "kechikayotgan"
                                ? t("latePaying")
                                : t("occupiedUnpaid")}
                      </div>
                    </div>
                    {result.apartment.customerInfo && (
                      <div className="mt-4 pt-4 border-t border-border/30">
                        <p className="font-medium text-sm sm:text-base">{result.apartment.customerInfo.name}</p>
                        <p className="text-xs sm:text-sm text-muted-foreground">
                          {result.apartment.customerInfo.phone}
                        </p>
                        {result.apartment.customerInfo.monthlyPayment && (
                          <p className="text-xs sm:text-sm text-muted-foreground mt-2">
                            {result.apartment.customerInfo.monthlyPayment.toLocaleString()} {t("monthlyPayment")}
                          </p>
                        )}
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            </div>
          ) : searchQuery.trim() ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground text-sm sm:text-base lg:text-lg">{t("noResults")}</p>
            </div>
          ) : null}

          {/* Stats Cards Grid - Large Display */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
            <div className="stat-card-telegram flex flex-col">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-blue-500" />
                <span className="text-xs sm:text-sm text-muted-foreground">{t("totalApartments")}</span>
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-foreground">{stats.totalApartments}</div>
            </div>
            <div className="stat-card-telegram flex flex-col">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-red-500" />
                <span className="text-xs sm:text-sm text-muted-foreground">{t("occupied")}</span>
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-foreground">{stats.occupied}</div>
              <div className="text-xs text-muted-foreground mt-1">
                {stats.totalApartments > 0 ? ((stats.occupied / stats.totalApartments) * 100).toFixed(1) : "0"}%
              </div>
            </div>
            <div className="stat-card-telegram flex flex-col">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <span className="text-xs sm:text-sm text-muted-foreground">{t("paid")}</span>
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-foreground">{stats.paid}</div>
              <div className="text-xs text-muted-foreground mt-1">
                {stats.totalApartments > 0 ? ((stats.paid / stats.totalApartments) * 100).toFixed(1) : "0"}%
              </div>
            </div>
            <div className="stat-card-telegram flex flex-col">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-gray-400" />
                <span className="text-xs sm:text-sm text-muted-foreground">{t("available")}</span>
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-foreground">{stats.available}</div>
              <div className="text-xs text-muted-foreground mt-1">
                {stats.totalApartments > 0 ? ((stats.available / stats.totalApartments) * 100).toFixed(1) : "0"}%
              </div>
            </div>
            <div className="stat-card-telegram flex flex-col">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-yellow-500" />
                <span className="text-xs sm:text-sm text-muted-foreground">{t("late")}</span>
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-foreground">{stats.late}</div>
              <div className="text-xs text-muted-foreground mt-1">
                {stats.totalApartments > 0 ? ((stats.late / stats.totalApartments) * 100).toFixed(1) : "0"}%
              </div>
            </div>
          </div>

          {/* Map Section */}
          <div className="mb-8">
            <ReadOnlyMap />
          </div>

          {/* Statistics Chart */}
          <Card className="card-telegram p-4 sm:p-5 lg:p-6 mb-8">
            <h2 className="text-lg sm:text-xl lg:text-2xl font-semibold mb-4">{t("statistics")}</h2>
            <ChartContainer config={chartConfig} className="h-[250px] sm:h-[300px] lg:h-[350px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorOccupied" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="rgb(220, 38, 38)" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="rgb(220, 38, 38)" stopOpacity={0.1} />
                    </linearGradient>
                    <linearGradient id="colorPaid" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="rgb(22, 163, 74)" stopOpacity={0.6} />
                      <stop offset="95%" stopColor="rgb(22, 163, 74)" stopOpacity={0.05} />
                    </linearGradient>
                    <linearGradient id="colorLate" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="rgb(234, 179, 8)" stopOpacity={0.7} />
                      <stop offset="95%" stopColor="rgb(234, 179, 8)" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={true} />
                  <XAxis
                    dataKey="date"
                    tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                    stroke="hsl(var(--border))"
                  />
                  <YAxis
                    tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                    stroke="hsl(var(--border))"
                    domain={[0, 100]}
                  />
                  <ChartTooltip
                    content={<ChartTooltipContent />}
                    cursor={{ stroke: "hsl(var(--border))", strokeWidth: 1 }}
                  />
                  <Area
                    type="monotone"
                    dataKey="occupied"
                    stroke="rgb(220, 38, 38)"
                    strokeWidth={2}
                    fill="url(#colorOccupied)"
                    fillOpacity={1}
                  />
                  <Area
                    type="monotone"
                    dataKey="paid"
                    stroke="rgb(22, 163, 74)"
                    strokeWidth={2}
                    fill="url(#colorPaid)"
                    fillOpacity={1}
                  />
                  <Area
                    type="monotone"
                    dataKey="late"
                    stroke="rgb(234, 179, 8)"
                    strokeWidth={2}
                    fill="url(#colorLate)"
                    fillOpacity={1}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </ChartContainer>
          </Card>

          {/* Block Cards Grid */}
          {displayedBlocks.length > 0 ? (
            <div className="mb-8">
              <h2 className="text-xl sm:text-2xl font-semibold mb-4">{t("blocks")}</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {displayedBlocks.map((block) => {
                  const blockStats = calculateBlockStats(block)
                  return (
                    <BlockCard
                      key={block.id}
                      blockId={block.id}
                      blockName={block.name}
                      totalFloors={block.totalFloors}
                      totalApartments={block.totalApartments}
                      bosh={blockStats.bosh}
                      band={blockStats.band}
                      tolangan={blockStats.tolangan}
                      kechikayotgan={blockStats.kechikayotgan}
                      t={t}
                    />
                  )
                })}
              </div>
            </div>
          ) : (
            <Card className="card-telegram p-6 sm:p-8 text-center mb-8">
              <p className="text-muted-foreground text-sm sm:text-base">
                Hech qanday blok ko'rsatilmayapti. Xaritaga bloklar qo'shish uchun{" "}
                <button onClick={() => router.push("/map")} className="text-accent hover:underline font-semibold">
                  xarita sahifasiga
                </button>{" "}
                o'ting.
              </p>
            </Card>
          )}

          {/* Legend */}
          <Card className="card-telegram p-4 sm:p-5">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-gray-400" />
                <span className="text-muted-foreground">{t("available")}</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <span className="text-muted-foreground">{t("occupied")}</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-green-500" />
                <span className="text-muted-foreground">{t("paid")}</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-yellow-500" />
                <span className="text-muted-foreground">{t("late")}</span>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Reset Dialog */}
      <AlertDialog open={showResetDialog} onOpenChange={setShowResetDialog}>
        <AlertDialogContent className="bg-card border-border rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-foreground">{t("resetAllApartments")}</AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground">{t("confirmReset")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-secondary text-secondary-foreground hover:bg-secondary/80 rounded-lg">
              {t("cancel")}
            </AlertDialogCancel>
            <AlertDialogAction onClick={handleReset} className="bg-red-500 hover:bg-red-600 text-white rounded-lg">
              {t("resetAllApartments")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
