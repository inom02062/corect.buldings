import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

interface BlockCardProps {
  blockId: string
  blockName: string
  totalFloors: number
  totalApartments: number
  bosh: number
  band: number
  tolangan: number
  kechikayotgan: number
  t: (key: string) => string
}

export function BlockCard({
  blockId,
  blockName,
  totalFloors,
  totalApartments,
  bosh,
  band,
  tolangan,
  kechikayotgan,
  t,
}: BlockCardProps) {
  return (
    <Card className="p-4 sm:p-5 lg:p-6 rounded-2xl border-border/30 bg-card shadow-sm hover:shadow-md transition-all duration-200">
      <h3 className="text-lg sm:text-xl font-semibold mb-2 text-foreground">{blockName}</h3>
      <p className="text-xs sm:text-sm text-muted-foreground mb-4">
        {totalFloors} {t("floor")} • {totalApartments} {t("apartment")}
      </p>

      <div className="flex flex-col gap-2 mb-4 text-xs sm:text-sm">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-gray-400 flex-shrink-0" />
          <span className="text-muted-foreground">{t("available")}:</span>
          <span className="font-medium ml-auto text-foreground">{bosh}</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-red-500 flex-shrink-0" />
          <span className="text-muted-foreground">{t("occupied")}:</span>
          <span className="font-medium ml-auto text-foreground">{band}</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-green-500 flex-shrink-0" />
          <span className="text-muted-foreground">{t("paid")}:</span>
          <span className="font-medium ml-auto text-foreground">{tolangan}</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-yellow-500 flex-shrink-0" />
          <span className="text-muted-foreground">{t("late")}:</span>
          <span className="font-medium ml-auto text-foreground">{kechikayotgan}</span>
        </div>
      </div>

      <Link href={`/block/${blockId}`}>
        <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground rounded-xl font-medium transition-all duration-200 text-xs sm:text-sm">
          {t("viewFloors")}
        </Button>
      </Link>
    </Card>
  )
}
