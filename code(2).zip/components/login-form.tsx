"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Eye, EyeOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { useAuth } from "@/lib/auth-context"

export function LoginForm() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { login } = useAuth()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      const success = await login(username, password)
      if (success) {
        router.push("/")
      } else {
        setError("Noto'g'ri login yoki parol")
      }
    } catch (error) {
      setError("Xatolik yuz berdi. Iltimos qayta urinib ko'ring")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-md card-telegram p-6 sm:p-8 border-0 shadow-lg">
      <div className="mb-8 text-center">
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">Kirish</h1>
        <p className="text-sm text-muted-foreground">Admin panel'ga xush kelibsiz</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Username Input */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Foydalanuvchi nomi</label>
          <Input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="Nomi kiriting"
            disabled={isLoading}
            className="bg-background border-border/30 rounded-xl"
            autoFocus
          />
        </div>

        {/* Password Input */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Parol</label>
          <div className="relative">
            <Input
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Parol kiriting"
              disabled={isLoading}
              className="bg-background border-border/30 rounded-xl pr-10"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              disabled={isLoading}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
            >
              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 px-4 py-3 rounded-lg text-sm">
            {error}
          </div>
        )}

        {/* Submit Button */}
        <Button
          type="submit"
          disabled={isLoading || !username || !password}
          className="w-full h-10 rounded-xl font-medium"
        >
          {isLoading ? "Kirish jarayonida..." : "Kirish"}
        </Button>

        {/* Demo Credentials */}
        <div className="mt-6 pt-6 border-t border-border/30">
          <p className="text-xs text-muted-foreground mb-3 font-medium">Test Login Credentials:</p>
          <div className="space-y-2 text-xs">
            <div className="bg-muted/50 p-2 rounded">
              <p className="font-mono">Admin: gtk / 12345</p>
            </div>
            <div className="bg-muted/50 p-2 rounded">
              <p className="font-mono">Manager: manager / manager123</p>
            </div>
            <div className="bg-muted/50 p-2 rounded">
              <p className="font-mono">Accountant: accountant / accountant123</p>
            </div>
            <div className="bg-muted/50 p-2 rounded">
              <p className="font-mono">Viewer: viewer / viewer123</p>
            </div>
          </div>
        </div>
      </form>
    </Card>
  )
}
