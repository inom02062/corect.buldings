import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

interface FloorCardProps {
  blockId: string
  floorNumber: number
  totalApartments: number
}

export function FloorCard({ blockId, floorNumber, totalApartments }: FloorCardProps) {
  return (
    <Card className="p-6 bg-gray-800/50 border-gray-700">
      <h3 className="text-xl font-semibold text-white mb-2">{floorNumber}-qavat</h3>
      <p className="text-sm text-gray-400 mb-4">{totalApartments} kvartira</p>

      <Link href={`/block/${blockId}/floor/${floorNumber}`}>
        <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">Ko'rish</Button>
      </Link>
    </Card>
  )
}
