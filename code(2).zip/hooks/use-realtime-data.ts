"use client"

import { useEffect, useState, useCallback } from "react"
import { realtimeSync } from "@/lib/realtime-sync"

interface UseRealtimeDataOptions {
  enabled?: boolean
  onError?: (error: Error) => void
}

/**
 * Hook for real-time data synchronization
 * Automatically syncs data when changes occur
 */
export function useRealtimeData<T>(
  resourceKey: string,
  initialData: T,
  fetchFn: () => Promise<T>,
  options: UseRealtimeDataOptions = {},
) {
  const [data, setData] = useState<T>(initialData)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<Error | null>(null)
  const { enabled = true, onError } = options

  // Initial fetch
  useEffect(() => {
    if (!enabled) return

    const fetchData = async () => {
      try {
        setLoading(true)
        const result = await fetchFn()
        setData(result)
        setError(null)
      } catch (err) {
        const error = err instanceof Error ? err : new Error(String(err))
        setError(error)
        onError?.(error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [enabled, fetchFn, onError])

  // Subscribe to real-time updates
  useEffect(() => {
    if (!enabled) return

    const subscription = realtimeSync.subscribe(resourceKey, (updatedData: T) => {
      setData(updatedData)
    })

    return () => subscription.unsubscribe()
  }, [resourceKey, enabled])

  // Manually refresh data
  const refresh = useCallback(async () => {
    try {
      setLoading(true)
      const result = await fetchFn()
      setData(result)
      setError(null)
    } catch (err) {
      const error = err instanceof Error ? err : new Error(String(err))
      setError(error)
      onError?.(error)
    } finally {
      setLoading(false)
    }
  }, [fetchFn, onError])

  return { data, loading, error, refresh }
}
